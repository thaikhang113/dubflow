#!/usr/bin/env python3
import hashlib, html, json, os, re, signal, subprocess, sys, time, urllib.parse, urllib.request, wave
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HOST = os.environ.get('OPENCLAW_DASHBOARD_HOST', '127.0.0.1')
PORT = int(os.environ.get('OPENCLAW_DASHBOARD_PORT', '18792'))
OUTPUT_ROOT = Path(os.environ.get('OPENCLAW_OUTPUT_ROOT', '/mnt/hdd500/video douyin vietsub'))
QUEUE_ROOT = OUTPUT_ROOT / 'host-runner-queue'
QUEUE_CANCELED_DIR = QUEUE_ROOT / 'canceled'
RUNNER_LOG_DIR = Path(os.environ.get('OPENCLAW_RUNNER_LOG_DIR', '/home/haonguyen/.openclaw-host-runner/logs'))
ALERT_STATE = Path(os.environ.get('OPENCLAW_DASHBOARD_ALERT_STATE', '/home/haonguyen/.openclaw-dashboard-alerts.json'))
TELEGRAM_CONFIG = Path(os.environ.get('TELEGRAM_CONFIG', '/home/haonguyen/.openclaw/config/channels/telegram.json'))
MONITOR_CHANNELS_FILE = Path(os.environ.get('OPENCLAW_MONITOR_CHANNELS_FILE', '/home/haonguyen/.openclaw/workspace/skills/content-monitor/channels.json'))
SERIES_TRACKER_SCRIPT = Path(os.environ.get('OPENCLAW_SERIES_TRACKER_SCRIPT', '/home/haonguyen/.openclaw/workspace/skills/series-tracker/series-tracker.py'))
THUMBNAIL_SCRIPT = Path(os.environ.get('OPENCLAW_THUMBNAIL_SCRIPT', '/home/haonguyen/.openclaw/workspace/skills/google-flow-thumbnail/google-flow-thumbnail.sh'))
HOST_RUNNER_SCRIPT = Path(os.environ.get('OPENCLAW_HOST_RUNNER_SCRIPT', '/home/haonguyen/.local/bin/openclaw-host-douyin-runner.sh'))
CAPCUT_VOICES_JSON = Path(os.environ.get('OPENCLAW_CAPCUT_VOICES_JSON', '/home/haonguyen/.openclaw/workspace/skills/douyin-vietnamese-dubber/capcut_voices.json'))
KOKORO_VOICES_JSON = Path(os.environ.get('OPENCLAW_KOKORO_VOICES_JSON', '/home/haonguyen/.openclaw/workspace/skills/douyin-vietnamese-dubber/kokoro_voices.json'))
DUBBER_SKILL_DIR = Path(os.environ.get('OPENCLAW_DUBBER_SKILL_DIR', '/home/haonguyen/.openclaw/workspace/skills/douyin-vietnamese-dubber'))
VOICE_REGISTRY_PY = Path(os.environ.get('OPENCLAW_VOICE_REGISTRY_PY', str(DUBBER_SKILL_DIR / 'voice_registry.py')))
AI33_TTS_WRAPPER = Path(os.environ.get('AI33_TTS_WRAPPER', str(DUBBER_SKILL_DIR / 'ai33_tts_synthesize.py')))
AI33_API_BASE = os.environ.get('AI33_API_BASE', 'https://api.ai33.pro')
VOICE_TEST_CACHE_DIR = Path(os.environ.get('OPENCLAW_VOICE_TEST_CACHE_DIR', '/tmp/openclaw-voice-test-cache'))
if str(DUBBER_SKILL_DIR) not in sys.path:
    sys.path.insert(0, str(DUBBER_SKILL_DIR))
try:
    import voice_registry as voice_registry_lib
except Exception:
    voice_registry_lib = None
AI33_MAI_PHUONG_VOICE_ID = os.environ.get('AI33_MAI_PHUONG_VOICE_ID', 'vbee_hn_female_maiphuong_vdts_48k-fhg')
AI33_MAI_PHUONG_VOICE = f'ai33:{AI33_MAI_PHUONG_VOICE_ID}'
AI33_PHANH_VOICE_ID = os.environ.get('AI33_PHANH_VOICE_ID', 'elevenlabs_UuMSQK8FdLwaY2M8ZAnh')
AI33_PHANH_VOICE = f'ai33:{AI33_PHANH_VOICE_ID}'
DEFAULT_VIDEO_VOICE_RAW = ''
if voice_registry_lib is not None:
    try:
        DEFAULT_VIDEO_VOICE_RAW = voice_registry_lib.default_voice()
    except Exception:
        DEFAULT_VIDEO_VOICE_RAW = ''
DEFAULT_VIDEO_VOICE_RAW = DEFAULT_VIDEO_VOICE_RAW or os.environ.get('OPENCLAW_DEFAULT_TTS_VOICE', AI33_MAI_PHUONG_VOICE)
if DEFAULT_VIDEO_VOICE_RAW == AI33_PHANH_VOICE and os.environ.get('OPENCLAW_KEEP_LEGACY_PHANH_DEFAULT') != '1' and voice_registry_lib is None:
    DEFAULT_VIDEO_VOICE_RAW = AI33_MAI_PHUONG_VOICE
KOKORO_DEFAULT_VIDEO_VOICE_RAW = os.environ.get('KOKORO_DEFAULT_VIDEO_VOICE', os.environ.get('KOKORO_DEFAULT_VOICE', 'mai_linh'))
KOKORO_DEFAULT_CHAT_VOICE_RAW = os.environ.get('OPENCLAW_CHAT_TTS_VOICE', 'kokoro:thanh_dat')
KOKORO_TTS_PYTHON = Path(os.environ.get('KOKORO_TTS_PYTHON', '/home/haonguyen/.local/share/openclaw-kokoro-venv/bin/python'))
KOKORO_TTS_DEVICE = os.environ.get('KOKORO_TTS_DEVICE', 'cpu') or 'cpu'
CHAT_TTS_CACHE_DIR = Path(os.environ.get('OPENCLAW_CHAT_TTS_CACHE_DIR', '/tmp/openclaw-chat-tts-cache'))
CHAT_TTS_CACHE_TTL_SECONDS = int(os.environ.get('OPENCLAW_CHAT_TTS_CACHE_TTL_SECONDS', str(24 * 3600)))
CHAT_TTS_MAX_CHARS = int(os.environ.get('OPENCLAW_CHAT_TTS_MAX_CHARS', '4000'))
CHAT_TTS_TIMEOUT_SECONDS = int(os.environ.get('OPENCLAW_CHAT_TTS_TIMEOUT_SECONDS', '180'))
DEFAULT_NINEROUTER_MODEL = os.environ.get('NINEROUTER_MODEL', 'ollama/minimax-m3:cloud')
DASHBOARD_URL = os.environ.get('OPENCLAW_DASHBOARD_URL', f'http://127.0.0.1:{PORT}')
ALERT_COOLDOWN_SECONDS = int(os.environ.get('OPENCLAW_DASHBOARD_ALERT_COOLDOWN_SECONDS', '1800'))
ALERT_RETRY_SECONDS = int(os.environ.get('OPENCLAW_DASHBOARD_ALERT_RETRY_SECONDS', '300'))
ALERT_MAX_PER_JOB = max(1, int(os.environ.get('OPENCLAW_DASHBOARD_ALERT_MAX_PER_JOB', '3')))
ALERT_MAX_JOB_AGE_SECONDS = int(os.environ.get('OPENCLAW_DASHBOARD_ALERT_MAX_JOB_AGE_SECONDS', str(6 * 3600)))
ENABLE_TELEGRAM_ALERTS = os.environ.get('OPENCLAW_DASHBOARD_TELEGRAM_ALERTS', '1') != '0'
VISIBLE_DAYS = int(os.environ.get('OPENCLAW_DASHBOARD_VISIBLE_DAYS', '4'))
VISIBLE_WINDOW_SECONDS = VISIBLE_DAYS * 24 * 3600

PHASES = [
    ('queued', 3, 'Đang chờ hàng đợi'),
    ('download', 12, 'Đang tải video'),
    ('preprocess', 25, 'Đang tách giọng/nhạc'),
    ('asr', 38, 'Đang nhận diện lời thoại'),
    ('postprocess_asr', 44, 'Đang lọc ASR'),
    ('optimizer', 58, 'Đang dịch/tối ưu timing'),
    ('tts', 72, 'Đang tạo giọng Việt'),
    ('mux', 84, 'Đang ghép audio/video'),
    ('subtitle_render', 87, 'Đang che sub gốc/chèn sub Việt'),
    ('thumbnail', 92, 'Đang tạo thumbnail'),
    ('organize', 98, 'Đang sắp xếp output'),
    ('completed', 100, 'Hoàn tất'),
]

ERROR_PATTERNS = [
    ('BilibiliLoginRequired', r'BilibiliLoginRequired|Bilibili.*login|Bilibili.*captcha|Bilibili.*verify'),
    ('BilibiliDownloadFailed', r'BilibiliDownloadFailed|yt-dlp tải Bilibili thất bại'),
    ('DouyinLoginRequired', r'LOGIN_REQUIRED|Fresh cookies|Phiên Douyin'),
    ('HostRunnerHTTP500', r'HTTP 500|returned error: 500'),
    ('DurationCheckFailed', r'Duration check failed|output không khớp master timeline'),
    ('GoogleFlowNeedsAttention', r'THUMBNAIL_NEEDS_ATTENTION|WARN_USER_ACTION_REQUIRED|quota/captcha|Google Flow.*limit'),
    ('AI33AuthMissing', r'AI33AuthMissing|thiếu env AI33_API_KEY'),
    ('AI33AuthFailed', r'AI33AuthFailed'),
    ('AI33QuotaFailed', r'AI33QuotaFailed'),
    ('AI33Timeout', r'AI33Timeout'),
    ('AI33NoAudioUrl', r'AI33NoAudioUrl'),
    ('TTSAI33Failed', r'TTSAI33Failed|AI33 TTS fail|AI33_GATE_FAIL'),
    ('ResonaAuthMissing', r'ResonaAuthMissing|thiếu env RESONA_API_TOKEN'),
    ('ResonaAuthFailed', r'ResonaAuthFailed'),
    ('ResonaQuotaFailed', r'ResonaQuotaFailed'),
    ('ResonaTimeout', r'ResonaTimeout'),
    ('ResonaTextTooShort', r'ResonaTextTooShort'),
    ('ResonaTextTooShortUngroupable', r'ResonaTextTooShortUngroupable'),
    ('ResonaCoverageTooLow', r'ResonaCoverageTooLow'),
    ('TTSResonaFailed', r'TTSResonaFailed|Resona TTS fail|RESONA_GATE_FAIL'),
    ('GenericError', r'(^|\b)ERROR[: ]'),
]

PHASE_PATTERNS = [
    ('completed', 100, 'Hoàn tất', r'HOÀN TẤT'),
    ('organize', 98, 'Đang sắp xếp output', r'Đang sắp xếp video final'),
    ('thumbnail', 92, 'Đang tạo thumbnail', r'Đang tạo thumbnail|google-flow-thumbnail|Thumbnail title'),
    ('subtitle_render', 87, 'Đang che sub gốc/chèn sub Việt', r'Đang che/mờ sub Trung|burn-in sub Việt|subtitle_render_ok'),
    ('mux', 84, 'Đang ghép audio/video', r'Đang ghép audio|Duration check'),
    ('tts', 72, 'Đang tạo giọng Việt', r'Đang tạo lồng tiếng|TTS progress'),
    ('manual_translate', 58, 'Đang chờ bạn dán bản dịch thủ công', r'TRANSLATE_PENDING|Đang chờ bạn dán bản dịch thủ công'),
    ('optimizer', 58, 'Đang dịch/tối ưu timing', r'Vietnamese Dub Timing Optimizer|Optimizer progress|Đang dịch original'),
    ('ocr_transcript', 45, 'Đang OCR subtitle gốc', r'Đang OCR subtitle Trung gốc|ocr_transcript|PP-OCR|PaddleOCR|PP-OCRv'),
    ('transcript_decision', 46, 'Đang chọn nguồn transcript', r'Đang chọn nguồn transcript|transcript_source_decision'),
    ('postprocess_asr', 44, 'Đang lọc ASR', r'Đang lọc hậu xử lý ASR'),
    ('asr', 38, 'Đang nhận diện lời thoại', r'Đang chạy Whisper|whisper_print_timings'),
    ('preprocess', 25, 'Đang tách giọng/nhạc', r'Speech-only preprocess|Đang tiền xử lý|demucs'),
    ('download', 12, 'Đang tải video', r'Đang tải video|download-video|yt-dlp|Đã tải Douyin|Bắt đầu Bilibili downloader|Đã tải Bilibili'),
    ('queued', 3, 'Đang chờ hàng đợi', r'Đang chờ lock|request='),
]

STUCK_LIMITS = {
    'download': 8 * 60,
    'preprocess': 10 * 60,
    'asr': 10 * 60,
    'ocr_transcript': 8 * 60,
    'transcript_decision': 3 * 60,
    'optimizer': 6 * 60,
    'tts': 8 * 60,
    'thumbnail': 5 * 60,
}

HEAVY_PROCESS_RE = re.compile(r'bilibili-vietnamese-dubber|douyin-vietnamese-dubber|openclaw-host-douyin-runner|yt-dlp|ffmpeg|whisper|demucs|edge-tts|google-flow-thumbnail|viet_dub|speech_only|ocr_subtitle_transcript|paddleocr|paddlex|PP-OCR', re.I)

def read_text(path, limit=65536):
    try:
        data = Path(path).read_bytes()
        if len(data) > limit:
            data = data[-limit:]
        return data.decode('utf-8', errors='replace')
    except Exception:
        return ''

def read_json(path):
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception:
        return None

RESONA_DEFAULT_VOICE_ID = os.environ.get('RESONA_DEFAULT_VOICE_ID', 'ZJEpWoOyElCKuEljNTkm')
RESONA_DEFAULT_VOICE = f'resona:{RESONA_DEFAULT_VOICE_ID}'
KOKORO_FALLBACK_VOICES = [
    {'id': 'mai_linh', 'label': 'Review phim - Mai Linh'},
    {'id': 'phat_tai', 'label': 'Review phim - Phat Tai'},
    {'id': 'duc_duy', 'label': 'Tin tuc - Duc Duy'},
    {'id': 'my_yen', 'label': 'Podcast - My Yen'},
    {'id': 'thanh_dat', 'label': 'Tin tuc/ke chuyen - Thanh Dat'},
    {'id': 'diem_trinh', 'label': 'Diem Trinh'},
    {'id': 'duc_an', 'label': 'Duc An'},
    {'id': 'hung_thinh', 'label': 'Hung Thinh'},
    {'id': 'mai_loan', 'label': 'Mai Loan'},
    {'id': 'manh_dung', 'label': 'Manh Dung'},
    {'id': 'ngoc_huyen', 'label': 'Ngoc Huyen'},
    {'id': 'storyvert', 'label': 'storyvert'},
    {'id': 'thuc_trinh', 'label': 'Thuc Trinh'},
    {'id': 'tuan_ngoc', 'label': 'Tuan Ngoc'},
]

def normalize_kokoro_voice_id(value, default='mai_linh'):
    raw = str(value or default).strip().lower()
    if raw.startswith('kokoro:'):
        raw = raw.split(':', 1)[1]
    raw = raw.replace('-', '_')
    voice_id = re.sub(r'[^a-z0-9_]+', '_', raw).strip('_')
    return voice_id or default

KOKORO_DEFAULT_VIDEO_VOICE_ID = normalize_kokoro_voice_id(KOKORO_DEFAULT_VIDEO_VOICE_RAW, 'mai_linh')
KOKORO_DEFAULT_VIDEO_VOICE = f'kokoro:{KOKORO_DEFAULT_VIDEO_VOICE_ID}'
KOKORO_DEFAULT_CHAT_VOICE_ID = normalize_kokoro_voice_id(KOKORO_DEFAULT_CHAT_VOICE_RAW, 'thanh_dat')
KOKORO_DEFAULT_CHAT_VOICE = f'kokoro:{KOKORO_DEFAULT_CHAT_VOICE_ID}'

def load_kokoro_voices():
    data = read_json(KOKORO_VOICES_JSON) or KOKORO_FALLBACK_VOICES
    voices = []
    seen = set()
    for item in data:
        if not isinstance(item, dict):
            continue
        voice_id = normalize_kokoro_voice_id(item.get('id') or item.get('voice_id') or item.get('name'), '')
        if not voice_id or voice_id in seen:
            continue
        seen.add(voice_id)
        label = str(item.get('label') or item.get('display_name') or voice_id).strip() or voice_id
        voices.append({'id': voice_id, 'label': label})
    return voices or KOKORO_FALLBACK_VOICES

def kokoro_voice_ids():
    return {item['id'] for item in load_kokoro_voices()}

def current_default_video_voice():
    if voice_registry_lib is not None:
        try:
            return voice_registry_lib.default_voice()
        except Exception:
            pass
    return DEFAULT_VIDEO_VOICE_RAW

def normalize_voice_value(value, default=None, strict=False):
    if default is None:
        default = current_default_video_voice()
    voice = str(value or default).strip()
    lower = voice.lower()
    if lower == '':
        return default
    if lower == 'kokoro':
        return default if str(default).lower().startswith('kokoro:') else KOKORO_DEFAULT_VIDEO_VOICE
    if lower.startswith('kokoro:'):
        voice_id = normalize_kokoro_voice_id(lower)
        if voice_id in kokoro_voice_ids():
            return f'kokoro:{voice_id}'
        if strict:
            raise ValueError(f'VoiceInvalid: Kokoro voice không hợp lệ: {voice}')
        return default
    raw_kokoro = normalize_kokoro_voice_id(lower, '')
    if raw_kokoro in kokoro_voice_ids():
        return f'kokoro:{raw_kokoro}'
    if lower == 'resona':
        return RESONA_DEFAULT_VOICE
    if lower.startswith('resona:'):
        return voice
    if lower in ('ai33', 'vbee', 'vbee-maiphuong', 'vbee-mai-phuong', 'maiphuong', 'mai-phuong', 'mai_phuong', 'elevenlabs', 'elevenlabs-phanh', 'eleven-phanh', 'phanh', 'phan') or lower.startswith('ai33:') or lower.startswith('elevenlabs_') or lower.startswith('vbee_'):
        if voice_registry_lib is not None:
            try:
                return voice_registry_lib.normalize_ai33_voice(voice)
            except Exception as exc:
                if strict:
                    raise ValueError(str(exc)) from exc
                return default
        if lower in ('ai33', 'vbee', 'vbee-maiphuong', 'vbee-mai-phuong', 'maiphuong', 'mai-phuong', 'mai_phuong'):
            return AI33_MAI_PHUONG_VOICE
        if lower in ('elevenlabs', 'elevenlabs-phanh', 'eleven-phanh', 'phanh', 'phan'):
            return AI33_PHANH_VOICE
        if lower.startswith('ai33:'):
            return voice
        return f'ai33:{voice}'
    if lower in ('nu', 'nữ', 'female', 'woman'):
        return 'nu'
    if lower in ('nam', 'male', 'man'):
        return 'nam'
    if lower.startswith('capcut:'):
        if strict:
            raise ValueError('VoiceInvalid: CapCut TTS đã tắt khỏi pipeline')
        return default
    if lower.startswith('vi-vn-'):
        return voice
    if strict and str(value or '').strip():
        raise ValueError(f'VoiceInvalid: preset giọng không hỗ trợ: {voice}')
    return default

def kokoro_voice_options_html(selected=None):
    selected = normalize_voice_value(selected or current_default_video_voice())
    parts = ['<optgroup label="Kokoro Vietnamese">']
    for item in load_kokoro_voices():
        value = f"kokoro:{item['id']}"
        attr = ' selected' if value == selected else ''
        parts.append(f'<option value="{html.escape(value)}"{attr}>{html.escape(item["label"])}</option>')
    parts.append('</optgroup>')
    return ''.join(parts)

def voice_options_html(selected=None):
    selected = normalize_voice_value(selected or current_default_video_voice())
    edge_nu = ' selected' if selected == 'nu' else ''
    edge_nam = ' selected' if selected == 'nam' else ''
    resona_default = ' selected' if selected == 'resona' or selected == RESONA_DEFAULT_VOICE else ''
    ai33_options = []
    try:
        voices = (voice_registry_lib.public_registry().get('voices') if voice_registry_lib is not None else None) or []
    except Exception:
        voices = []
    if not voices:
        voices = [
            {'canonical_voice': AI33_MAI_PHUONG_VOICE, 'label': 'Mai Phuong - Vbee', 'enabled': True},
            {'canonical_voice': AI33_PHANH_VOICE, 'label': 'Phanh - ElevenLabs', 'enabled': True},
        ]
    for item in voices:
        if not item.get('enabled', True):
            continue
        value = str(item.get('canonical_voice') or f"ai33:{item.get('voice_id', '')}")
        if not value.startswith('ai33:'):
            continue
        attr = ' selected' if value == selected else ''
        label = str(item.get('label') or item.get('voice_id') or value)
        default_mark = ' (mặc định)' if value == current_default_video_voice() else ''
        ai33_options.append(f'<option value="{html.escape(value)}"{attr}>{html.escape(label + default_mark)}</option>')
    return (
        kokoro_voice_options_html(selected)
        + f'<optgroup label="Edge TTS"><option value="nu"{edge_nu}>Nữ Edge (HoaiMy)</option><option value="nam"{edge_nam}>Nam Edge</option></optgroup>'
        + f'<optgroup label="AI33 Pro registry">{"".join(ai33_options)}</optgroup>'
        + f'<optgroup label="Thử nghiệm (Resona)"><option value="resona"{resona_default}>Resona - Phương Thảo</option><option value="resona:0phiCO46biYtwYYP0DIR">Resona - Nữ Tuệ An</option></optgroup>'
    )

def kokoro_runtime_env():
    return {
        'KOKORO_DEFAULT_VOICE': KOKORO_DEFAULT_VIDEO_VOICE_ID,
        'KOKORO_TTS_PYTHON': str(KOKORO_TTS_PYTHON),
        'KOKORO_TTS_DEVICE': KOKORO_TTS_DEVICE,
        'KOKORO_VOICES_JSON': str(KOKORO_VOICES_JSON),
    }

def normalize_bgm_mode(mode):
    value = str(mode or 'auto').strip().lower()
    if value in ('auto', 'duck', 'none', 'demucs'):
        return value
    return 'auto'

def normalize_ai_model(model):
    value = str(model or DEFAULT_NINEROUTER_MODEL).strip()
    if value and re.match(r'^[A-Za-z0-9._:/+-]+$', value):
        return value
    return DEFAULT_NINEROUTER_MODEL

def load_capcut_vn_voices():
    data = read_json(CAPCUT_VOICES_JSON) or []
    voices = []
    seen = set()
    for item in data:
        if not isinstance(item, dict):
            continue
        if (item.get('lang') or item.get('lan')) != 'vi-VN':
            continue
        voice_type = str(item.get('voice_type') or '').strip()
        resource_id = str(item.get('resource_id') or '').strip()
        display_name = str(item.get('display_name') or voice_type).strip()
        if not voice_type or not resource_id or voice_type in seen:
            continue
        seen.add(voice_type)
        voices.append({'voice_type': voice_type, 'resource_id': resource_id, 'display_name': display_name})
    return voices

def capcut_voice_options_html():
    # CapCut TTS is disabled from the pipeline. Keep the function so the
    # template replacement remains stable, but render no CapCut options.
    return ''

def mtime(path):
    try:
        return Path(path).stat().st_mtime
    except Exception:
        return 0

def fmt_epoch(epoch):
    if not epoch:
        return ''
    return time.strftime('%F %T', time.localtime(epoch))

def fmt_day_label(epoch):
    if not epoch:
        return 'Không rõ ngày'
    return time.strftime('%d/%m/%Y %H:%M:%S', time.localtime(epoch))

def tail_lines(text, count=80):
    return '\n'.join(text.splitlines()[-count:])

def parse_req(path):
    data = {}
    for line in read_text(path, 4096).splitlines():
        if '=' in line:
            k, v = line.split('=', 1)
            data[k] = v
    return data

def detect_optimizer_progress(log_text):
    match_total = re.search(r'Optimizer progress:\s+parsed\s+\d+\s+segments\s+into\s+(\d+)\s+timing groups', log_text, re.I)
    opt_total = max(1, int(match_total.group(1))) if match_total else None
    probing = re.findall(r'Optimizer progress:\s+probing/rewrite timing group\s+(\d+)/(\d+)', log_text, re.I)
    if probing:
        current, total = map(int, probing[-1])
        total = max(1, total)
        pct = 58 + int(min(1.0, current / total) * 7)
        return 'optimizer', pct, f'Đang kiểm tra/rút gọn timing ({current}/{total})'
    translated = re.findall(r'Optimizer progress:\s+translated groups\s+\d+-(\d+)/(\d+)', log_text, re.I)
    if translated:
        done, total = map(int, translated[-1])
        total = max(1, total)
        pct = 46 + int(min(1.0, done / total) * 12)
        return 'optimizer', pct, f'Đang dịch/tối ưu timing ({done}/{total})'
    translating = re.findall(r'Optimizer progress:\s+translating groups\s+\d+-(\d+)/(\d+)', log_text, re.I)
    if translating:
        done, total = map(int, translating[-1])
        total = max(1, total)
        pct = 45 + int(min(1.0, done / total) * 10)
        return 'optimizer', pct, f'Đang dịch/tối ưu timing ({done}/{total})'
    if opt_total:
        return 'optimizer', 45, f'Đang chuẩn bị tối ưu timing ({opt_total} nhóm)'
    return None


def detect_phase(log_text, status):
    if status:
        return status.get('phase') or 'unknown', int(status.get('progress_percent') or 0), status.get('phase_label_vi') or 'Đang xử lý'
    opt = detect_optimizer_progress(log_text)
    if opt:
        return opt
    for phase, pct, label, pattern in PHASE_PATTERNS:
        if re.search(pattern, log_text, re.I | re.M):
            return phase, pct, label
    return 'unknown', 0, 'Chưa có dữ liệu'

def detect_error(log_text, job_dir):
    job_path = Path(job_dir) if job_dir else None
    status = read_json(job_path / 'job_status.json') if job_path else None
    status_completed = False
    if status:
        status_completed = (
            status.get('state') == 'completed'
            or status.get('phase') == 'completed'
            or int(status.get('progress_percent') or 0) >= 100
        )
    completed_success = bool(status_completed and job_path and (job_path / 'final_video_vi.mp4').exists())
    if status and (status.get('error_code') or status.get('error_message')) and not completed_success:
        return status.get('error_code') or 'PipelineError', status.get('error_message') or ''
    if status and status.get('state') == 'running':
        updated = float(status.get('updated_at_epoch') or 0)
        if updated and time.time() - updated < 5 * 60:
            return '', ''
    if job_path and (job_path / 'THUMBNAIL_NEEDS_ATTENTION.txt').exists():
        return 'GoogleFlowNeedsAttention', read_text(job_path / 'THUMBNAIL_NEEDS_ATTENTION.txt', 2000).strip()
    if completed_success:
        return '', ''
    for code, pattern in ERROR_PATTERNS:
        match = re.search(pattern, log_text, re.I | re.M)
        if match:
            return code, match.group(0)[:300]
    return '', ''

def process_rows():
    try:
        out = subprocess.check_output(['ps', '-eo', 'pid=,pgid=,args='], text=True, timeout=3)
    except Exception:
        return []
    rows = []
    for line in out.splitlines():
        parts = line.strip().split(None, 2)
        if len(parts) < 3:
            continue
        try:
            rows.append({'pid': int(parts[0]), 'pgid': int(parts[1]), 'args': parts[2]})
        except Exception:
            continue
    return rows

def active_processes():
    try:
        out = subprocess.check_output(['ps', '-ef'], text=True, timeout=3)
    except Exception:
        return []
    return [line for line in out.splitlines() if HEAVY_PROCESS_RE.search(line) and 'openclaw-dashboard' not in line]

def recent_9router_call(seconds=1800):
    try:
        out = subprocess.check_output(['journalctl', '--user', '-u', '9router.service', '--since', f'{seconds} seconds ago', '--no-pager'], text=True, timeout=5, stderr=subprocess.DEVNULL)
    except Exception:
        return {'seen': False, 'last_line': '', 'age_seconds': None}
    lines = [line for line in out.splitlines() if re.search(r'POST /v1/(chat/completions|responses)|\[CHAT\]|\[COMBO\]|\[REQUEST\]', line)]
    return {'seen': bool(lines), 'last_line': lines[-1] if lines else '', 'age_seconds': 0 if lines else None}

def load_latest_output():
    path = OUTPUT_ROOT / 'LATEST_OUTPUT_DIR.txt'
    text = read_text(path, 4096).strip()
    return Path(text) if text else None

def load_bilibili_latest_output():
    path = OUTPUT_ROOT / 'Bilibili' / 'LATEST_OUTPUT_DIR.txt'
    text = read_text(path, 4096).strip()
    return Path(text) if text else None

def find_job_dirs(limit=20):
    dirs = []
    if OUTPUT_ROOT.exists():
        for item in OUTPUT_ROOT.iterdir():
            if item.is_dir() and item.name.startswith('video-'):
                dirs.append(item)
        bili_root = OUTPUT_ROOT / 'Bilibili'
        if bili_root.exists():
            for item in bili_root.iterdir():
                if item.is_dir() and item.name != 'source-cache' and ((item / 'log.txt').exists() or (item / 'job_status.json').exists() or (item / 'final_video_vi.mp4').exists()):
                    dirs.append(item)
    dirs.sort(key=lambda p: mtime(p), reverse=True)
    latest = load_latest_output()
    if latest and latest.exists() and latest not in dirs:
        dirs.insert(0, latest)
    bili_latest = load_bilibili_latest_output()
    if bili_latest and bili_latest.exists() and bili_latest not in dirs:
        dirs.insert(0, bili_latest)
    return dirs[:limit]

def collect_queue_jobs():
    jobs = []
    for state in ('requests', 'done', 'failed', 'canceled'):
        root = QUEUE_ROOT / state
        if not root.exists():
            continue
        for req in sorted(root.glob('*.req'), key=lambda p: mtime(p), reverse=True)[:20]:
            data = parse_req(req)
            log = QUEUE_ROOT / 'logs' / (req.name + '.log')
            log_text = read_text(log)
            phase, pct, label = detect_phase(log_text, None)
            if state == 'requests':
                phase, pct, label = 'queued', 3, 'Đang chờ runner xử lý'
            ui_state = {'requests': 'queued', 'done': 'completed', 'failed': 'error', 'canceled': 'canceled'}.get(state, state)
            error_code, error_message = ('CanceledByUser', 'Bạn đã hủy job này từ dashboard') if state == 'canceled' else detect_error(log_text, '')
            jobs.append({
                'id': req.stem,
                'type': 'queue',
                'platform': 'bilibili' if data.get('ACTION') in ('run-bilibili', 'bilibili-find') or 'bilibili.com' in data.get('URL', '') else 'douyin',
                'source_title': '',
                'state': ui_state,
                'queue_state': state,
                'source_url': data.get('URL', ''),
                'voice': data.get('VOICE_PRESET', ''),
                'request_path': str(req),
                'log_path': str(log),
                'log_mtime': mtime(log) or mtime(req),
                'created_at': fmt_epoch(mtime(req)),
                'updated_at': fmt_epoch(mtime(log) or mtime(req)),
                'day_label': fmt_day_label(mtime(log) or mtime(req)),
                'age_seconds': max(0, int(time.time() - (mtime(log) or mtime(req) or time.time()))),
                'phase': phase,
                'phase_label_vi': label,
                'progress_percent': pct,
                'error_code': error_code,
                'error_message': error_message,
                'last_log_line': last_log_line(log_text),
            })
    return jobs

def last_log_line(text):
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    return lines[-1] if lines else ''

def collect_artifact_job(job_dir):
    status = read_json(job_dir / 'job_status.json')
    log_text = read_text(job_dir / 'log.txt')
    if status and mtime(job_dir / 'log.txt') > mtime(job_dir / 'job_status.json') + 10:
        log_phase, log_pct, log_label = detect_phase(log_text, None)
        status_pct = int(status.get('progress_percent') or 0)
        if log_pct >= status_pct:
            phase, pct, label = log_phase, log_pct, log_label
        else:
            phase, pct, label = detect_phase(log_text, status)
    else:
        phase, pct, label = detect_phase(log_text, status)
    error_code, error_message = detect_error(log_text, job_dir)
    thumb_status = read_json(job_dir / 'thumbnail_flow_status.json')
    thumb_bridge_status = read_json(job_dir / 'thumbnail_flow_bridge_status.json')
    timeline_report = read_json(job_dir / 'timeline_duration_report.json')
    fit_adjustments = read_json(job_dir / 'fit_adjustments.json')
    voice_sync_report = read_json(job_dir / 'voice_sync_quality_report.json')
    translate_pending = (job_dir / 'TRANSLATE_PENDING.txt').exists()
    canceled_marker = job_dir / 'CANCELED_BY_DASHBOARD.txt'
    state = 'completed' if (job_dir / 'final_video_vi.mp4').exists() and phase == 'completed' else 'running'
    if canceled_marker.exists():
        state = 'canceled'
        phase = 'canceled'
        pct = min(99, max(pct, 1))
        label = 'Đã dừng theo yêu cầu'
        error_code = 'CanceledByUser'
        error_message = read_text(canceled_marker, 1000).strip() or 'Bạn đã hủy job này từ dashboard'
    if state != 'canceled' and error_code and error_code != 'GoogleFlowNeedsAttention':
        state = 'error'
    elif error_code == 'GoogleFlowNeedsAttention':
        state = 'warning'
    created_epoch = mtime(job_dir)
    updated_epoch = max(mtime(job_dir / 'job_status.json'), mtime(job_dir / 'log.txt'), mtime(job_dir))
    age = max(0, int(time.time() - updated_epoch))
    # Ưu tiên error thật (PipelineError/dependency fail) lên trên manual_translate:
    # nếu job đã chết vì thiếu dependency (vd. edge-tts) thì hiện error đó, không
    # chuyển thành "chờ manual translate" khiến user tưởng chỉ cần dán bản dịch tay.
    has_real_error = bool(error_code) and error_code not in ('GoogleFlowNeedsAttention',)
    if translate_pending and state != 'completed' and not has_real_error:
        state = 'warning'
        phase = 'manual_translate'
        pct = max(pct, 58)
        label = 'Chưa tạo được bản dịch tự động'
        error_code = error_code or 'ManualTranslatePending'
        error_message = error_message or 'Pipeline chưa tạo được bản dịch tự động; bấm “Chạy tiếp từ job cũ” để tự dịch lại (không cần dán tay). Nếu vẫn lỗi, dán transcript_vi.json rồi bấm tiếp.'
    if state == 'running' and phase in STUCK_LIMITS and age > STUCK_LIMITS[phase]:
        state = 'warning'
        if not error_code:
            error_code = 'StuckHeartbeat'
            error_message = f'Không thấy log/heartbeat mới {age}s ở phase {phase}'
    if state == 'running' and phase in ('preprocess', 'asr', 'ocr_transcript', 'transcript_decision', 'tts', 'mux', 'subtitle_render', 'thumbnail') and age > 180 and not active_processes():
        state = 'error'
        error_code = error_code or 'NoHeavyProcess'
        if phase == 'ocr_transcript':
            error_message = error_message or 'Đang bị treo ở OCR subtitle gốc: log/heartbeat đã đứng và không còn process PaddleOCR/python xử lý. Có thể bấm Chạy tiếp từ job cũ để fallback ASR và đi tiếp.'
        else:
            error_message = error_message or 'Không thấy process xử lý nặng trong lúc job có vẻ đang chạy'
    api = recent_9router_call(1800) if phase == 'optimizer' else {'seen': False, 'last_line': '', 'age_seconds': None}
    if state == 'running' and phase == 'optimizer' and age > STUCK_LIMITS['optimizer'] and not api['seen']:
        state = 'error'
        error_code = error_code or 'No9RouterCall'
        error_message = error_message or 'Giai đoạn optimizer cần API nhưng không thấy 9Router call gần đây'
    if error_code == 'GoogleFlowNeedsAttention' and isinstance(thumb_status, dict) and thumb_status.get('status') == 'done' and not (job_dir / 'THUMBNAIL_NEEDS_ATTENTION.txt').exists():
        error_code, error_message = '', ''
        if state == 'warning':
            state = 'completed' if (job_dir / 'final_video_vi.mp4').exists() and phase == 'completed' else 'running'
    source_url = read_text(job_dir / 'source_input.txt', 4096).strip()
    platform = read_text(job_dir / 'source_platform.txt', 200).strip()
    if not platform:
        platform = 'bilibili' if 'bilibili.com' in source_url else 'douyin' if 'douyin.com' in source_url or 'iesdouyin.com' in source_url else 'local'
    source_title = read_text(job_dir / 'source_title.txt', 1000).strip()
    return {
        'id': job_dir.name,
        'type': 'job_dir',
        'platform': platform,
        'source_title': source_title,
        'state': state,
        'job_dir': str(job_dir),
        'source_url': source_url,
        'voice': status.get('voice') if isinstance(status, dict) else '',
        'phase': phase,
        'phase_label_vi': label,
        'progress_percent': pct,
        'last_log_line': last_log_line(log_text) or (status or {}).get('last_log_line') or '',
        'log_path': str(job_dir / 'log.txt'),
        'log_mtime': updated_epoch,
        'created_at': fmt_epoch(created_epoch),
        'updated_at': fmt_epoch(updated_epoch),
        'day_label': fmt_day_label(updated_epoch),
        'age_seconds': age,
        'error_code': error_code,
        'error_message': error_message,
        'final_video': str(job_dir / 'final_video_vi.mp4') if (job_dir / 'final_video_vi.mp4').exists() else '',
        'thumbnail': str(job_dir / 'thumbnail.jpg') if (job_dir / 'thumbnail.jpg').exists() else '',
        'thumbnail_status': thumb_status,
        'thumbnail_bridge_status': thumb_bridge_status,
        'timeline_report': timeline_report,
        'fit_adjustments': fit_adjustments,
        'voice_sync_report': voice_sync_report,
        'translate_pending': translate_pending,
        'nine_router_recent': api,
    }

def detect_channel_platform(channel):
    platform = (channel.get('platform') or '').lower()
    if platform:
        return platform
    url = (channel.get('url') or '').lower()
    if 'bilibili.com' in url or 'b23.tv' in url:
        return 'bilibili'
    if 'douyin.com' in url or 'iesdouyin.com' in url or 'tiktok.com' in url:
        return 'douyin'
    return 'unknown'

def load_monitor_channels():
    data = read_json(MONITOR_CHANNELS_FILE)
    if not isinstance(data, list):
        return []
    channels = []
    for index, channel in enumerate(data, 1):
        if not isinstance(channel, dict):
            continue
        url = str(channel.get('url') or '')
        name = str(channel.get('name') or 'Unknown')
        platform = detect_channel_platform(channel)
        channels.append({
            'index': index,
            'name': name,
            'url': url,
            'platform': platform,
            'added_at': channel.get('added_at') or '',
            'copy_text': f'{name} | {url}',
        })
    return channels


def run_series_tracker(args, timeout=120):
    if not SERIES_TRACKER_SCRIPT.exists():
        return {'ok': False, 'error': f'Không tìm thấy series tracker: {SERIES_TRACKER_SCRIPT}'}
    cmd = ['python3', str(SERIES_TRACKER_SCRIPT), *args]
    try:
        proc = subprocess.run(cmd, text=True, capture_output=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return {'ok': False, 'error': 'Series tracker chạy quá lâu/timeout'}
    stdout = (proc.stdout or '').strip()
    stderr = (proc.stderr or '').strip()
    if proc.returncode != 0:
        return {'ok': False, 'returncode': proc.returncode, 'error': stderr or stdout or 'series tracker failed'}
    if not stdout:
        return {'ok': True}
    try:
        data = json.loads(stdout)
    except Exception:
        return {'ok': True, 'stdout': stdout, 'stderr': stderr}
    if isinstance(data, dict) and 'ok' not in data:
        data['ok'] = True
    return data

def run_series_runner(action, payload, timeout=120):
    if not HOST_RUNNER_SCRIPT.exists():
        return {'ok': False, 'error': f'Không tìm thấy host runner: {HOST_RUNNER_SCRIPT}'}
    try:
        proc = subprocess.run(['bash', str(HOST_RUNNER_SCRIPT), action, json.dumps(payload, ensure_ascii=False, separators=(',', ':'))], text=True, capture_output=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return {'ok': False, 'error': 'Series runner chạy quá lâu/timeout'}
    stdout, stderr = (proc.stdout or '').strip(), (proc.stderr or '').strip()
    try:
        result = json.loads(stdout)
    except Exception:
        result = {'ok': proc.returncode == 0, 'stdout': stdout}
    if isinstance(result, dict):
        result['ok'] = bool(result.get('ok', proc.returncode == 0)) and proc.returncode == 0
        if not result['ok']:
            result['error'] = result.get('error') or stderr or stdout or 'series runner failed'
    return result

def series_list_payload(payload=None):
    payload = payload or {}
    series_id = payload.get('series_id')
    if series_id is not None and (not isinstance(series_id, str) or not COMPILATION_ID_RE.fullmatch(series_id)):
        return {'ok': False, 'error': 'series_id không hợp lệ'}
    return run_series_runner('series-list', {'series_id': series_id} if series_id else {}, timeout=30)

def series_add_payload(payload):
    name = str(payload.get('name') or '').strip()
    keyword = str(payload.get('keyword') or '').strip()
    source_url = str(payload.get('source_url') or payload.get('sourceUrl') or '').strip()
    channel_url = str(payload.get('channel_url') or payload.get('channelUrl') or '').strip()
    if not name or not keyword or not source_url:
        return {'ok': False, 'error': 'Thiếu Tên series, Keyword hoặc Link video/series gốc'}
    args = ['add', '--name', name, '--keyword', keyword, '--source-url', source_url]
    if channel_url:
        args += ['--channel-url', channel_url]
    return run_series_tracker(args, timeout=60)

def series_refresh_payload(payload):
    series_id = payload.get('series_id')
    limit = payload.get('limit', 100)
    if not isinstance(series_id, str) or not COMPILATION_ID_RE.fullmatch(series_id):
        return {'ok': False, 'error': 'Thiếu series_id'}
    if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 500:
        return {'ok': False, 'error': 'limit phải là số nguyên từ 1 đến 500'}
    return run_series_runner('series-refresh', {'series_id': series_id, 'limit': limit}, timeout=180)

def series_download_payload(payload):
    series_id = payload.get('series_id')
    episode_numbers = payload.get('episode_numbers')
    selector = payload.get('selector')
    url = payload.get('url')
    if not isinstance(series_id, str) or not COMPILATION_ID_RE.fullmatch(series_id):
        return {'ok': False, 'error': 'series_id không hợp lệ'}
    if (episode_numbers is None) == (selector is None):
        return {'ok': False, 'error': 'Cần đúng một trong episode_numbers hoặc selector'}
    if episode_numbers is not None and (not isinstance(episode_numbers, list) or not episode_numbers or any(isinstance(n, bool) or not isinstance(n, int) or n < 1 for n in episode_numbers)):
        return {'ok': False, 'error': 'episode_numbers phải là mảng số tập dương'}
    if selector is not None and (not isinstance(selector, str) or not re.fullmatch(r'(?:all|latest:[1-9][0-9]*|range:[1-9][0-9]*-[1-9][0-9]*|list:[1-9][0-9]*(?:,[1-9][0-9]*)*)', selector)):
        return {'ok': False, 'error': 'selector không hợp lệ'}
    if url is not None and (not isinstance(url, str) or not re.fullmatch(r'https?://(?:www\.)?bilibili\.com/video/[A-Za-z0-9]+[^\s]*', url)):
        return {'ok': False, 'error': 'Chỉ nhận link tập Bilibili trực tiếp'}
    try:
        voice = normalize_voice_value(payload.get('voice'), strict=True)
    except ValueError as exc:
        return {'ok': False, 'error': str(exc)}
    bgm_mode = normalize_bgm_mode(payload.get('bgm_mode') or 'auto')
    ai_model = normalize_ai_model(payload.get('ninerouter_model'))
    safe = {'series_id': series_id, 'voice': voice, 'bgm_mode': bgm_mode, 'ninerouter_model': ai_model}
    if episode_numbers is not None:
        safe['episode_numbers'] = episode_numbers
    else:
        safe['selector'] = selector
    if url is not None:
        safe['url'] = url
    return run_series_runner('series-download', safe, timeout=60)


COMPILATION_ID_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$')
COMPILATION_SELECTOR_RE = re.compile(r'^(?:all|latest|latest:[1-9][0-9]*|unprocessed|range:[0-9]+-[0-9]+|list:[0-9]+(?:,[0-9]+)*)$')
assert COMPILATION_SELECTOR_RE.fullmatch('latest:5')
assert not COMPILATION_SELECTOR_RE.fullmatch('latest:0')
COMPILATION_BRANDING_KEYS = {'blur_logo', 'blur_title', 'replace_logo'}
COMPILATION_REGION_REQUIRED_KEYS = {'x', 'y', 'width', 'height', 'start', 'end', 'confidence'}
COMPILATION_REGION_OPTIONAL_KEYS = {'blur', 'replacement', 'confirmed', 'label'}
COMPILATION_REGION_KEYS = COMPILATION_REGION_REQUIRED_KEYS | COMPILATION_REGION_OPTIONAL_KEYS
COMPILATION_OUTPUT_ROOT = OUTPUT_ROOT / 'compilations'
COMPILATION_PREVIEW_MAX_BYTES = 12 * 1024 * 1024
COMPILATION_PREVIEW_TYPES = {'.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg'}

def _safe_compilation_json(value, depth=0):
    """Accept bounded JSON values only; compilation paths are runner-owned."""
    if depth > 4:
        return False
    if value is None or isinstance(value, (bool, int, float)):
        return not isinstance(value, float) or value == value and abs(value) != float('inf')
    if isinstance(value, str):
        return len(value) <= 200 and '\x00' not in value and not any(c in value for c in ('/', '\\'))
    if isinstance(value, list):
        return len(value) <= 50 and all(_safe_compilation_json(item, depth + 1) for item in value)
    if isinstance(value, dict):
        return len(value) <= 20 and all(isinstance(k, str) and len(k) <= 40 and _safe_compilation_json(v, depth + 1) for k, v in value.items())
    return False

def _validated_compilation_id(value):
    value = str(value or '').strip()
    return value if COMPILATION_ID_RE.fullmatch(value) else None

def _compilation_preview_file(compilation_id, index=None, episode=None):
    """Resolve a runner-owned preview without accepting a caller path."""
    ident = _validated_compilation_id(compilation_id)
    if not ident or (index is None and episode is None):
        return None
    if index is not None:
        try:
            index = int(index)
        except (TypeError, ValueError):
            return None
        if index < 0 or index > 500:
            return None
    if episode is not None:
        try:
            episode = int(episode)
        except (TypeError, ValueError):
            return None
        if episode < 1 or episode > 100000:
            return None
    root = (COMPILATION_OUTPUT_ROOT / ident).resolve()
    if root.parent != COMPILATION_OUTPUT_ROOT.resolve() or not root.is_dir():
        return None
    records = []
    for name in ('status.json', 'manifest.json'):
        data = read_json(root / name)
        found = data.get('overlay_detections') if isinstance(data, dict) else None
        if isinstance(found, dict):
            records.extend((key, value) for key, value in found.items())
        elif isinstance(found, list):
            records.extend((None, value) for value in found)
        if records:
            break
    candidates = []
    for keyed_episode, record in records:
        if not isinstance(record, dict):
            continue
        record_episode = record.get('episode_number')
        if record_episode is not None and keyed_episode is not None and str(record_episode) != str(keyed_episode):
            continue
        if record_episode is None:
            record_episode = keyed_episode
        if episode is not None and str(record_episode) != str(episode):
            continue
        previews = record.get('previews') or record.get('sampled_frame_previews') or []
        if isinstance(previews, str):
            previews = [previews]
        if isinstance(previews, list):
            candidates.extend(item for item in previews if isinstance(item, str))
    if index is None:
        index = 0
    if index >= len(candidates):
        return None
    candidate = Path(candidates[index])
    try:
        resolved = candidate.resolve()
        if resolved.parent != root and root not in resolved.parents:
            return None
        if resolved.suffix.lower() not in COMPILATION_PREVIEW_TYPES or not resolved.is_file():
            return None
        if resolved.stat().st_size > COMPILATION_PREVIEW_MAX_BYTES:
            return None
        return resolved
    except (OSError, RuntimeError):
        return None

def compilation_request_payload(payload, command):
    if not isinstance(payload, dict):
        return None, 'Payload phải là JSON object'
    allowed_fields = {'compilation_id', 'compilationId', 'series_id', 'seriesId', 'selector', 'max_seconds', 'voice', 'branding', 'overlay_regions', 'order', 'split_episodes', 'include_intro', 'include_outro'}
    if set(payload) - allowed_fields:
        return None, 'Payload có trường không được phép'
    compilation_id = str(payload.get('compilation_id') or payload.get('compilationId') or '').strip()
    if not COMPILATION_ID_RE.fullmatch(compilation_id):
        return None, 'compilation_id không hợp lệ'
    safe = {'compilation_id': compilation_id}
    if command == 'plan':
        selector = str(payload.get('selector') or 'all').strip().lower()
        if not COMPILATION_SELECTOR_RE.fullmatch(selector):
            return None, 'selector phải là all, latest, latest:N (N > 0), unprocessed, range:1-3 hoặc list:1,2'
        safe['selector'] = selector
        series_id = payload.get('series_id') or payload.get('seriesId')
        if series_id is not None and str(series_id).strip():
            series_id = str(series_id).strip()
            if not COMPILATION_ID_RE.fullmatch(series_id):
                return None, 'series_id không hợp lệ'
            safe['series_id'] = series_id
        max_seconds = payload.get('max_seconds', 5400)
        if isinstance(max_seconds, bool):
            return None, 'max_seconds phải là số nguyên'
        try:
            max_seconds = int(max_seconds)
        except (TypeError, ValueError):
            return None, 'max_seconds phải là số nguyên'
        safe['max_seconds'] = max(1, min(max_seconds, 5400))
        if payload.get('order', 'source') != 'source':
            return None, 'order chỉ hỗ trợ source'
        if payload.get('split_episodes', False) is not False:
            return None, 'split_episodes phải là false'
        safe.update({'order': 'source', 'split_episodes': False})
        for key in ('include_intro', 'include_outro'):
            value = payload.get(key, False)
            if not isinstance(value, bool):
                return None, f'{key} phải là boolean'
            safe[key] = value
        branding = payload.get('branding')
        if branding is not None:
            if not isinstance(branding, dict) or set(branding) - COMPILATION_BRANDING_KEYS or not all(isinstance(v, bool) for v in branding.values()):
                return None, 'branding không hợp lệ'
            safe['branding'] = {key: bool(branding.get(key, False)) for key in COMPILATION_BRANDING_KEYS if key in branding}
        overlay_regions = payload.get('overlay_regions')
        if overlay_regions is not None:
            def valid_region(region):
                if isinstance(region, dict):
                    region = dict(region)
                    if 'start_seconds' in region:
                        if 'start' in region:
                            return False
                        region['start'] = region.pop('start_seconds')
                    if 'end_seconds' in region:
                        if 'end' in region:
                            return False
                        region['end'] = region.pop('end_seconds')
                    region.setdefault('label', 'overlay')
                if (not isinstance(region, dict) or set(region) - COMPILATION_REGION_KEYS
                        or not COMPILATION_REGION_REQUIRED_KEYS <= set(region)
                        or not _safe_compilation_json(region)):
                    return False
                for key in ('x', 'y', 'width', 'height'):
                    if isinstance(region[key], bool) or not isinstance(region[key], int) or region[key] < 0:
                        return False
                if region['width'] < 4 or region['height'] < 4:
                    return False
                for key in ('start', 'end', 'confidence'):
                    if isinstance(region[key], bool) or not isinstance(region[key], (int, float)):
                        return False
                if region['start'] < 0 or region['end'] <= region['start'] or not 0 <= region['confidence'] <= 1:
                    return False
                if not (region.get('blur') is True or region.get('replacement') is True):
                    return False
                if 'blur' in region and not isinstance(region['blur'], bool):
                    return False
                if 'replacement' in region and not isinstance(region['replacement'], bool):
                    return False
                if 'label' in region and (not isinstance(region['label'], str) or not region['label'].strip()):
                    return False
                return region['confidence'] >= 0.8 or region.get('confirmed') is True
            if not isinstance(overlay_regions, list) or not all(valid_region(region) for region in overlay_regions):
                return None, 'overlay_regions không hợp lệ'
            normalized_regions = []
            for region in overlay_regions:
                region = dict(region)
                region['start'] = region.pop('start_seconds', region.get('start'))
                region['end'] = region.pop('end_seconds', region.get('end'))
                region.setdefault('label', 'overlay')
                normalized_regions.append(region)
            safe['overlay_regions'] = normalized_regions
        if payload.get('voice') is not None:
            try:
                safe['voice'] = normalize_voice_value(payload.get('voice'), strict=True)
            except ValueError as exc:
                return None, str(exc)
    return safe, None

def run_compilation_runner(command, payload):
    """Call the fixed host runner with its JSON-only compilation interface."""
    safe, error = compilation_request_payload(payload, command)
    if error:
        return {'ok': False, 'error': error}
    if not HOST_RUNNER_SCRIPT.exists():
        return {'ok': False, 'error': f'Không tìm thấy host runner: {HOST_RUNNER_SCRIPT}'}
    action = f'series-compilation-{command}'
    raw_payload = json.dumps(safe, ensure_ascii=False, separators=(',', ':'))
    try:
        proc = subprocess.run(['bash', str(HOST_RUNNER_SCRIPT), action, raw_payload], text=True, capture_output=True, timeout=180)
    except subprocess.TimeoutExpired:
        return {'ok': False, 'error': 'Compilation runner chạy quá lâu/timeout'}
    stdout, stderr = (proc.stdout or '').strip(), (proc.stderr or '').strip()
    result = None
    for line in reversed(stdout.splitlines()):
        try:
            candidate = json.loads(line)
            if isinstance(candidate, dict):
                result = candidate
                break
        except json.JSONDecodeError:
            continue
    if result is None:
        result = {'ok': proc.returncode == 0, 'output': stdout[-800:]}
    result['ok'] = bool(result.get('ok', proc.returncode == 0)) and proc.returncode == 0
    if not result['ok']:
        result['error'] = result.get('error') or stderr[-800:] or stdout[-800:] or 'compilation runner failed'
    return result

def compilation_plan_payload(payload):
    return run_compilation_runner('plan', payload)

def compilation_run_payload(payload):
    return run_compilation_runner('run', payload)

def compilation_status_payload(payload):
    return run_compilation_runner('status', payload)

def compilation_resume_payload(payload):
    return run_compilation_runner('resume', payload)

def compilation_cancel_payload(payload):
    return run_compilation_runner('cancel', payload)


def is_safe_output_dir(path_text):
    try:
        path = Path(path_text).resolve()
        root = OUTPUT_ROOT.resolve()
        return path.is_dir() and (path == root or root in path.parents), path
    except Exception:
        return False, Path(path_text or '')

def start_background_command(cmd, log_path, env=None):
    log_path = Path(log_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    proc_env = os.environ.copy()
    if env:
        proc_env.update({str(k): str(v) for k, v in env.items() if v is not None})
    with log_path.open('ab') as log:
        log.write((f"\n== dashboard retry {time.strftime('%F %T')} ==\ncmd: {' '.join(map(str, cmd))}\n").encode('utf-8', errors='replace'))
        proc = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, start_new_session=True, env=proc_env)
    return {'pid': proc.pid, 'log_path': str(log_path)}

def retry_job_payload(payload):
    mode = str(payload.get('mode') or '').strip().lower()
    job_dir_text = str(payload.get('job_dir') or payload.get('jobDir') or '').strip()
    source_url = str(payload.get('source_url') or payload.get('sourceUrl') or '').strip()
    platform = str(payload.get('platform') or '').strip().lower()
    try:
        voice = normalize_voice_value(payload.get('voice'), strict=True)
    except ValueError as exc:
        return {'ok': False, 'error': str(exc)}
    ai_model = normalize_ai_model(payload.get('model') or payload.get('ninerouter_model'))
    safe, job_dir = is_safe_output_dir(job_dir_text)
    if mode in ('', 'auto'):
        if safe and (job_dir / 'final_video_vi.mp4').exists():
            mode = 'thumbnail'
        elif source_url:
            mode = 'pipeline'
        else:
            return {'ok': False, 'error': 'Không đủ dữ liệu để retry job này'}
    if mode == 'thumbnail':
        if not safe:
            return {'ok': False, 'error': 'Job dir không hợp lệ hoặc không nằm trong output root'}
        if not (job_dir / 'final_video_vi.mp4').exists():
            return {'ok': False, 'error': 'Job chưa có final_video_vi.mp4 nên không thể retry thumbnail-only'}
        if not THUMBNAIL_SCRIPT.exists():
            return {'ok': False, 'error': f'Không tìm thấy thumbnail script: {THUMBNAIL_SCRIPT}'}
        result = start_background_command(['bash', str(THUMBNAIL_SCRIPT), str(job_dir)], job_dir / 'dashboard_retry_thumbnail.log')
        return {'ok': True, 'mode': 'thumbnail', **result}
    if mode == 'pipeline':
        if not HOST_RUNNER_SCRIPT.exists():
            return {'ok': False, 'error': f'Không tìm thấy host runner: {HOST_RUNNER_SCRIPT}'}
        if 'bilibili.com/video/' in source_url:
            action = 'run-bilibili'
        elif 'douyin.com/video/' in source_url or 'iesdouyin.com' in source_url:
            action = 'run-douyin'
        else:
            return {'ok': False, 'error': 'Chỉ retry pipeline cho link video Bilibili/Douyin trực tiếp'}
        bgm_mode = normalize_bgm_mode(payload.get('bgm_mode') or 'auto')
        result = start_background_command(['bash', str(HOST_RUNNER_SCRIPT), action, source_url, voice, bgm_mode], RUNNER_LOG_DIR / f'dashboard-retry-{int(time.time())}.log', env={'NINEROUTER_MODEL': ai_model, **kokoro_runtime_env()})
        return {'ok': True, 'mode': 'pipeline', 'action': action, **result}
    if mode in ('resume', 'continue'):
        if not safe:
            return {'ok': False, 'error': 'Job dir không hợp lệ hoặc không nằm trong output root'}
        input_video = job_dir / 'input.mp4'
        if not input_video.exists():
            return {'ok': False, 'error': 'Job cũ chưa có input.mp4 nên không thể chạy tiếp tại chỗ'}
        run_script = Path('/home/haonguyen/.openclaw/workspace/skills/douyin-vietnamese-dubber/run.sh')
        if not run_script.exists():
            return {'ok': False, 'error': f'Không tìm thấy pipeline run.sh: {run_script}'}
        env = {
            'OPENCLAW_RESUME_JOB_DIR': str(job_dir),
            'DOUYIN_RESUME_JOB_DIR': str(job_dir),
            'DOUYIN_VIDEOS_DIR': str(job_dir.parent),
            'SOURCE_URL_OVERRIDE': source_url or read_text(job_dir / 'source_input.txt', 4096).strip(),
            'SOURCE_PLATFORM': platform or read_text(job_dir / 'source_platform.txt', 200).strip(),
            'SOURCE_TITLE': read_text(job_dir / 'source_title.txt', 1000).strip(),
            'EDGE_TTS_VOICE_PRESET': voice,
            'DOUYIN_TTS_VOICE_PRESET': voice,
            **kokoro_runtime_env(),
            'OCR_TRANSCRIPT_REBUILD': '0',
            'OCR_TRANSCRIPT_TIMEOUT_SECONDS': os.environ.get('OCR_TRANSCRIPT_TIMEOUT_SECONDS', '900'),
            'BGM_MODE': normalize_bgm_mode(payload.get('bgm_mode') or 'auto'),
            'BGM_MODE_FALLBACK': 'duck',
            'NINEROUTER_MODEL': ai_model,
        }
        # Resume gọi thẳng pipeline run.sh (không qua host-runner), nên PATH của
        # dashboard process có thể thiếu ~/.local/bin -> edge-tts (pip --user) không
        # thấy -> PipelineError "Thiếu lệnh 'edge-tts'". Ép ~/.local/bin lên đầu PATH.
        home_local = os.path.expanduser('~/.local/bin')
        cur_path = env.get('PATH') or os.environ.get('PATH') or ''
        if os.path.isdir(home_local) and f'{home_local}:' not in cur_path and f':{home_local}' not in cur_path:
            env['PATH'] = f'{home_local}:{cur_path}'
        try:
            (job_dir / 'CANCELED_BY_DASHBOARD.txt').unlink()
        except FileNotFoundError:
            pass
        except Exception:
            pass
        result = start_background_command(['bash', str(run_script), str(input_video)], job_dir / 'dashboard_resume.log', env=env)
        return {'ok': True, 'mode': 'resume', **result}
    return {'ok': False, 'error': 'mode retry không hỗ trợ'}

def cleanup_chat_tts_cache():
    try:
        CHAT_TTS_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    except Exception:
        return
    cutoff = time.time() - CHAT_TTS_CACHE_TTL_SECONDS
    for path in CHAT_TTS_CACHE_DIR.glob('*.wav'):
        try:
            if path.is_file() and path.stat().st_mtime < cutoff:
                path.unlink()
        except Exception:
            pass

def chat_tts_cache_file(raw_name):
    name = urllib.parse.unquote(str(raw_name or ''))
    if name != Path(name).name:
        return None
    if not re.match(r'^[A-Za-z0-9_.:-]+\.wav$', name):
        return None
    try:
        root = CHAT_TTS_CACHE_DIR.resolve()
        path = (CHAT_TTS_CACHE_DIR / name).resolve()
        if path.parent != root:
            return None
        return path
    except Exception:
        return None

def synthesize_chat_tts_payload(payload):
    cleanup_chat_tts_cache()
    text = re.sub(r'\s+', ' ', str(payload.get('text') or '')).strip()
    if not text:
        return {'ok': False, 'error': 'Thiếu text'}
    if len(text) > CHAT_TTS_MAX_CHARS:
        text = text[:CHAT_TTS_MAX_CHARS]
    voice = normalize_voice_value(payload.get('voice') or KOKORO_DEFAULT_CHAT_VOICE, default=KOKORO_DEFAULT_CHAT_VOICE)
    if not voice.startswith('kokoro:'):
        voice = KOKORO_DEFAULT_CHAT_VOICE
    voice_id = normalize_kokoro_voice_id(voice, KOKORO_DEFAULT_CHAT_VOICE_ID)
    digest = hashlib.sha256((voice + '\0' + text).encode('utf-8')).hexdigest()[:24]
    filename = f'{voice_id}-{digest}.wav'
    CHAT_TTS_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    out_path = CHAT_TTS_CACHE_DIR / filename
    if out_path.exists() and out_path.stat().st_size > 44:
        return {'ok': True, 'audio_url': f'/tts-cache/{urllib.parse.quote(filename)}', 'voice': voice, 'cached': True}
    if not KOKORO_TTS_PYTHON.exists():
        return {'ok': False, 'error': f'Kokoro runtime chưa sẵn sàng: {KOKORO_TTS_PYTHON}'}
    tmp_path = out_path.with_suffix('.tmp.wav')
    try:
        tmp_path.unlink()
    except FileNotFoundError:
        pass
    except Exception:
        pass
    script = r"""
import os, sys
import soundfile as sf
from kokoro_vietnamese import KokoroVietnamese, SAMPLE_RATE
text, voice_id, out_path = sys.argv[1], sys.argv[2], sys.argv[3]
tts = KokoroVietnamese(device=os.environ.get("KOKORO_TTS_DEVICE", "cpu"), voice=voice_id)
audio, _ = tts.synthesize(text)
sf.write(out_path, audio, SAMPLE_RATE)
"""
    env = os.environ.copy()
    env.update(kokoro_runtime_env())
    proc = subprocess.run(
        [str(KOKORO_TTS_PYTHON), '-c', script, text, voice_id, str(tmp_path)],
        text=True,
        capture_output=True,
        timeout=CHAT_TTS_TIMEOUT_SECONDS,
        env=env,
    )
    if proc.returncode != 0 or not tmp_path.exists() or tmp_path.stat().st_size <= 44:
        try:
            tmp_path.unlink()
        except Exception:
            pass
        err = (proc.stderr or proc.stdout or '').strip()[-500:]
        return {'ok': False, 'error': 'KokoroTTSFailed', 'stderr': err}
    tmp_path.replace(out_path)
    return {'ok': True, 'audio_url': f'/tts-cache/{urllib.parse.quote(filename)}', 'voice': voice, 'cached': False}


def _voice_registry_required():
    if voice_registry_lib is None:
        raise RuntimeError('VoiceRegistryInvalid: không load được voice_registry.py')
    return voice_registry_lib

def voices_payload():
    try:
        vr = _voice_registry_required()
        data = vr.public_registry()
        data['voice_options_html'] = voice_options_html(data.get('default_voice'))
        return data
    except Exception as exc:
        return {'ok': False, 'error': str(exc)}

def voice_add_payload(payload):
    try:
        vr = _voice_registry_required()
        data = vr.add_ai33_voice({
            'voice_input': payload.get('voice_input') or payload.get('voiceInput') or payload.get('voice_url') or payload.get('voiceUrl') or payload.get('voice_id') or payload.get('voiceId') or payload.get('url') or payload.get('link'),
            'voice_id': payload.get('voice_id') or payload.get('voiceId'),
            'voice_url': payload.get('voice_url') or payload.get('voiceUrl') or payload.get('url') or payload.get('link'),
            'label': payload.get('label') or payload.get('display_name') or payload.get('displayName'),
            'aliases': payload.get('aliases') or '',
            'enabled': True,
            'set_default': bool(payload.get('set_default') or payload.get('setDefault')),
            'timing_profile': payload.get('timing_profile') or 'ai33_balanced_fast',
            'min_slow_ratio': payload.get('min_slow_ratio') or 0.85,
        })
        return {'ok': True, 'registry': data, 'warning': 'Job đầu tiên với giọng mới cần xem voice_sync report.' if payload.get('set_default') or payload.get('setDefault') else ''}
    except Exception as exc:
        return {'ok': False, 'error': str(exc)}

def voice_default_payload(payload):
    try:
        vr = _voice_registry_required()
        voice = payload.get('voice') or payload.get('canonical_voice') or payload.get('canonicalVoice') or payload.get('voice_id') or payload.get('voiceId')
        data = vr.set_default_voice(str(voice or ''))
        return {'ok': True, 'registry': data, 'warning': 'Job đầu tiên với giọng mới cần xem voice_sync report.'}
    except Exception as exc:
        return {'ok': False, 'error': str(exc)}

def voice_disable_payload(payload):
    try:
        vr = _voice_registry_required()
        voice = payload.get('voice') or payload.get('canonical_voice') or payload.get('canonicalVoice') or payload.get('voice_id') or payload.get('voiceId')
        data = vr.disable_voice(str(voice or ''))
        return {'ok': True, 'registry': data}
    except Exception as exc:
        return {'ok': False, 'error': str(exc)}

def voice_restore_payload(payload):
    try:
        vr = _voice_registry_required()
        data = vr.restore_latest_backup()
        return {'ok': True, 'registry': data}
    except Exception as exc:
        return {'ok': False, 'error': str(exc)}

def voice_test_cache_file(raw_name):
    name = urllib.parse.unquote(str(raw_name or ''))
    if name != Path(name).name:
        return None
    if not re.match(r'^[A-Za-z0-9_.:-]+\.wav$', name):
        return None
    try:
        root = VOICE_TEST_CACHE_DIR.resolve()
        path = (VOICE_TEST_CACHE_DIR / name).resolve()
        if path.parent != root:
            return None
        return path
    except Exception:
        return None

def _wav_duration_ms(path):
    try:
        with wave.open(str(path), 'rb') as wf:
            rate = wf.getframerate() or 1
            frames = wf.getnframes()
            return int(round(frames * 1000 / rate))
    except Exception:
        return 0

def voice_test_payload(payload):
    try:
        vr = _voice_registry_required()
        canonical = vr.normalize_ai33_voice(payload.get('voice') or payload.get('voice_id') or payload.get('voiceId') or '')
        meta = vr.ai33_metadata(canonical)
        text = re.sub(r'\s+', ' ', str(payload.get('text') or 'Xin chào, đây là bản thử giọng AI ba ba của OpenClaw.')).strip()
        if len(text) > 160:
            text = text[:160]
        if not text:
            return {'ok': False, 'error': 'Thiếu câu test'}
        if not AI33_TTS_WRAPPER.exists():
            return {'ok': False, 'error': f'Không tìm thấy AI33 wrapper: {AI33_TTS_WRAPPER}'}
        digest = hashlib.sha256((canonical + '\0' + text).encode('utf-8')).hexdigest()[:24]
        filename = f"ai33-{digest}.wav"
        VOICE_TEST_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        out_path = VOICE_TEST_CACHE_DIR / filename
        if out_path.exists() and out_path.stat().st_size > 256:
            return {
                'ok': True,
                'provider': 'ai33',
                'voice_id': meta.get('voice_id'),
                'canonical_voice': canonical,
                'audio_url': f'/voice-test-cache/{urllib.parse.quote(filename)}',
                'duration_ms': _wav_duration_ms(out_path),
                'cached': True,
            }
        tmp_path = out_path.with_suffix('.tmp.wav')
        try:
            tmp_path.unlink()
        except FileNotFoundError:
            pass
        except Exception:
            pass
        proc = subprocess.run(
            [
                'python3', str(AI33_TTS_WRAPPER),
                '--text', text,
                '--voice', str(meta.get('voice_id') or ''),
                '--output', str(tmp_path),
                '--api-base', AI33_API_BASE,
                '--timeout-total', str(int(os.environ.get('OPENCLAW_VOICE_TEST_TIMEOUT_SECONDS', '90'))),
                '--poll-interval', str(float(os.environ.get('AI33_POLL_INTERVAL_SECONDS', '2'))),
            ],
            text=True,
            capture_output=True,
            timeout=int(os.environ.get('OPENCLAW_VOICE_TEST_TIMEOUT_SECONDS', '90')) + 10,
            env=os.environ.copy(),
        )
        if proc.returncode != 0 or not tmp_path.exists() or tmp_path.stat().st_size <= 256:
            err = (proc.stderr or proc.stdout or 'AI33 test failed')
            secret = os.environ.get('AI33_API_KEY', '') or os.environ.get('AI33_ACCESS_TOKEN', '')
            if secret:
                err = err.replace(secret, '[redacted]')
            return {'ok': False, 'provider': 'ai33', 'voice_id': meta.get('voice_id'), 'canonical_voice': canonical, 'error': err[-500:]}
        tmp_path.replace(out_path)
        return {
            'ok': True,
            'provider': 'ai33',
            'voice_id': meta.get('voice_id'),
            'canonical_voice': canonical,
            'audio_url': f'/voice-test-cache/{urllib.parse.quote(filename)}',
            'duration_ms': _wav_duration_ms(out_path),
            'cached': False,
        }
    except Exception as exc:
        return {'ok': False, 'error': str(exc)}


def series_job_status_payload(payload):
    job_id = str(payload.get('job_id') or payload.get('jobId') or '').strip()
    if not job_id:
        return {'ok': False, 'error': 'Thiếu job_id'}
    return run_series_tracker(['job-status', job_id], timeout=30)

def append_cancel_log(path, message):
    try:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('a', encoding='utf-8') as fp:
            fp.write(f"\n== dashboard cancel {time.strftime('%F %T')} ==\n{message}\n")
    except Exception:
        pass

def safe_queue_path(path_text, expected_parent=None):
    try:
        path = Path(path_text).resolve()
        root = QUEUE_ROOT.resolve()
        if root != path and root not in path.parents:
            return None
        if expected_parent and path.parent.name != expected_parent:
            return None
        return path
    except Exception:
        return None

def find_queue_request(job_id, request_path=''):
    if request_path:
        req = safe_queue_path(request_path)
        if req and req.exists():
            return req
    safe_id = re.sub(r'[^A-Za-z0-9._-]+', '_', str(job_id or '').strip())
    if not safe_id:
        return None
    for folder in ('requests', 'done', 'failed', 'canceled'):
        req = QUEUE_ROOT / folder / f'{safe_id}.req'
        if req.exists():
            return req
    return None

def mark_job_canceled(job_dir, reason):
    safe, path = is_safe_output_dir(str(job_dir))
    if not safe:
        return False
    message = reason or 'Bạn đã hủy job này từ dashboard'
    (path / 'CANCELED_BY_DASHBOARD.txt').write_text(message + '\n', encoding='utf-8')
    status_path = path / 'job_status.json'
    status = read_json(status_path) or {}
    status.update({
        'status_schema': 1,
        'job_dir': str(path),
        'phase': 'canceled',
        'phase_label_vi': 'Đã dừng theo yêu cầu',
        'progress_percent': int(status.get('progress_percent') or 0),
        'state': 'canceled',
        'error_code': 'CanceledByUser',
        'error_message': message,
        'last_heartbeat_at': time.strftime('%F %T %z'),
        'updated_at_epoch': time.time(),
    })
    tmp = status_path.with_suffix('.json.tmp')
    tmp.write_text(json.dumps(status, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    tmp.replace(status_path)
    append_cancel_log(path / 'log.txt', message)
    return True

def kill_matching_job_processes(tokens):
    tokens = [str(t).strip() for t in tokens if str(t or '').strip()]
    if not tokens:
        return []
    allowed = re.compile(r'openclaw-host-douyin-runner|douyin-vietnamese-dubber|bilibili-vietnamese-dubber|run\.sh|yt-dlp|ffmpeg|whisper|demucs|edge-tts|capcut_tts_synthesize|google-flow-thumbnail', re.I)
    own = os.getpid()
    pgids = set()
    matched = []
    for row in process_rows():
        args = row['args']
        if row['pid'] == own or 'openclaw-dashboard' in args:
            continue
        if not allowed.search(args):
            continue
        if any(token in args for token in tokens):
            pgids.add(row['pgid'])
            matched.append({'pid': row['pid'], 'pgid': row['pgid'], 'args': args[:240]})
    for pgid in sorted(pgids):
        try:
            os.killpg(pgid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        except Exception:
            try:
                os.kill(pgid, signal.SIGTERM)
            except Exception:
                pass
    return matched

def cancel_job_payload(payload):
    job_id = str(payload.get('id') or payload.get('job_id') or payload.get('jobId') or '').strip()
    request_path = str(payload.get('request_path') or payload.get('requestPath') or '').strip()
    job_dir_text = str(payload.get('job_dir') or payload.get('jobDir') or '').strip()
    source_url = str(payload.get('source_url') or payload.get('sourceUrl') or '').strip()
    reason = f"Hủy từ dashboard lúc {time.strftime('%F %T')}"

    canceled = []
    req = find_queue_request(job_id, request_path)
    if req and req.parent.name == 'requests':
        QUEUE_CANCELED_DIR.mkdir(parents=True, exist_ok=True)
        target = QUEUE_CANCELED_DIR / req.name
        log = QUEUE_ROOT / 'logs' / (req.name + '.log')
        append_cancel_log(log, reason)
        req.replace(target)
        canceled.append({'type': 'queued_request', 'path': str(target)})
    elif req and req.parent.name == 'canceled':
        canceled.append({'type': 'queued_request', 'path': str(req), 'already': True})

    safe_job = False
    if job_dir_text:
        safe_job, job_dir = is_safe_output_dir(job_dir_text)
        if safe_job:
            mark_job_canceled(job_dir, reason)
            canceled.append({'type': 'job_dir', 'path': str(job_dir)})
    else:
        job_dir = None

    tokens = [job_id, source_url]
    if safe_job and job_dir:
        tokens.append(str(job_dir))
        try:
            tokens.append(str((job_dir / 'input.mp4').resolve()))
        except Exception:
            pass
    killed = kill_matching_job_processes(tokens)

    if not canceled and not killed:
        return {'ok': False, 'error': 'Không tìm thấy job đang chờ/chạy để dừng'}
    return {'ok': True, 'canceled': canceled, 'killed': killed}


def collect_status():
    jobs = []
    seen = set()
    for job_dir in find_job_dirs(20):
        if str(job_dir) in seen:
            continue
        seen.add(str(job_dir))
        jobs.append(collect_artifact_job(job_dir))
    active_sources = {job.get('source_url') for job in jobs if job.get('type') == 'job_dir' and job.get('source_url')}
    for queue_job in collect_queue_jobs():
        if queue_job.get('source_url') in active_sources:
            continue
        jobs.append(queue_job)
    cutoff = time.time() - VISIBLE_WINDOW_SECONDS
    jobs = [job for job in jobs if (job.get('log_mtime') or 0) >= cutoff or job.get('state') in ('queued', 'running')]
    jobs.sort(key=lambda j: j.get('log_mtime') or 0, reverse=True)
    procs = active_processes()
    payload = {
        'ok': True,
        'generated_at': time.strftime('%F %T %z'),
        'output_root': str(OUTPUT_ROOT),
        'dashboard_url': DASHBOARD_URL,
        'visible_days': VISIBLE_DAYS,
        'active_processes': procs[:20],
        'monitor_channels': load_monitor_channels(),
        'jobs': jobs[:40],
    }
    maybe_send_alerts(payload)
    return payload

def load_alert_state():
    try:
        return json.loads(ALERT_STATE.read_text(encoding='utf-8'))
    except Exception:
        return {}

def save_alert_state(data):
    ALERT_STATE.parent.mkdir(parents=True, exist_ok=True)
    tmp = ALERT_STATE.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    tmp.replace(ALERT_STATE)

def coerce_alert_record(value):
    if isinstance(value, dict):
        return {
            'sent_count': int(value.get('sent_count') or value.get('count') or 0),
            'last_sent_at': float(value.get('last_sent_at') or value.get('last_sent') or 0),
            'first_sent_at': float(value.get('first_sent_at') or value.get('first_sent') or 0),
        }
    try:
        last_sent = float(value or 0)
    except Exception:
        last_sent = 0.0
    return {
        'sent_count': 1 if last_sent else 0,
        'last_sent_at': last_sent,
        'first_sent_at': last_sent,
    }

def clear_alert_records_for_job(state, job_id):
    prefix = f"{job_id}::"
    keys = [key for key in state if key.startswith(prefix)]
    for key in keys:
        state.pop(key, None)
    return bool(keys)

def load_telegram():
    token = os.environ.get('TELEGRAM_BOT_TOKEN', '')
    chat = os.environ.get('TELEGRAM_CHAT_ID', '')
    thread = os.environ.get('TELEGRAM_MESSAGE_THREAD_ID', '') or os.environ.get('MESSAGE_THREAD_ID', '')
    if token and chat:
        return token, chat, str(thread)
    try:
        data = json.loads(TELEGRAM_CONFIG.read_text(encoding='utf-8'))
        telegram = data.get('telegram', data)
        bots = telegram.get('bots') or []
        if not token and bots and isinstance(bots[0], dict):
            token = bots[0].get('token') or ''
        if not chat:
            chat = telegram.get('chatId') or telegram.get('chat_id') or ''
        if not thread:
            thread = telegram.get('messageThreadId') or telegram.get('message_thread_id') or ''
    except Exception:
        pass
    return token, str(chat), str(thread)

def send_telegram(text):
    if not ENABLE_TELEGRAM_ALERTS:
        return False
    token, chat, thread = load_telegram()
    if not token or not chat:
        return False
    body = {'chat_id': chat, 'text': text[:3800], 'disable_web_page_preview': 'true'}
    if thread:
        body['message_thread_id'] = thread
    data = urllib.parse.urlencode(body).encode()
    req = urllib.request.Request(f'https://api.telegram.org/bot{token}/sendMessage', data=data, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            payload = json.loads(resp.read().decode('utf-8') or '{}')
            return 200 <= resp.status < 300 and bool(payload.get('ok'))
    except Exception:
        return False

def maybe_send_alerts(payload):
    state = load_alert_state()
    now = time.time()
    changed = False
    for job in payload.get('jobs', []):
        job_id = str(job.get('id') or '')
        if job.get('state') not in ('error', 'warning') or not job.get('error_code'):
            if job_id:
                changed = clear_alert_records_for_job(state, job_id) or changed
            continue
        if int(job.get('age_seconds') or 0) > ALERT_MAX_JOB_AGE_SECONDS:
            continue
        key = f"{job_id}::{job.get('error_code')}"
        total_key = f"{job_id}::__job_fail_total"
        record = coerce_alert_record(state.get(key))
        total_record = coerce_alert_record(state.get(total_key))
        if record['sent_count'] >= ALERT_MAX_PER_JOB or total_record['sent_count'] >= ALERT_MAX_PER_JOB:
            continue
        if now - record['last_sent_at'] < ALERT_COOLDOWN_SECONDS:
            continue
        failed_key = f"{key}::send_failed"
        last_failed = float(state.get(failed_key, 0) or 0)
        if now - last_failed < ALERT_RETRY_SECONDS:
            continue
        alert_number = total_record['sent_count'] + 1
        text = (
            f"🚨 OpenClaw Dashboard cảnh báo\n"
            f"Lần: {alert_number}/{ALERT_MAX_PER_JOB}\n"
            f"Lỗi: {job.get('error_code')}\n"
            f"Job: {job_id}\n"
            f"Phase: {job.get('phase_label_vi')} ({job.get('progress_percent')}%)\n"
            f"Source: {job.get('source_url') or '-'}\n"
            f"Log cuối: {job.get('last_log_line') or job.get('error_message') or '-'}\n"
            f"Dashboard: {DASHBOARD_URL}"
        )
        if send_telegram(text):
            first_sent = record['first_sent_at'] or now
            state[key] = {
                'sent_count': record['sent_count'] + 1,
                'first_sent_at': first_sent,
                'last_sent_at': now,
                'last_error_code': job.get('error_code') or '',
                'last_phase': job.get('phase') or '',
            }
            state[total_key] = {
                'sent_count': total_record['sent_count'] + 1,
                'first_sent_at': total_record['first_sent_at'] or now,
                'last_sent_at': now,
            }
            state.pop(failed_key, None)
        else:
            state[failed_key] = now
        changed = True
    if changed:
        save_alert_state(state)

INDEX_HTML = r'''<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>OpenClaw Dashboard</title>
<style>
body{font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:#0f172a;color:#e5e7eb;margin:0;padding:18px}.top{display:flex;justify-content:space-between;gap:12px;align-items:center}.card{background:#111827;border:1px solid #263244;border-radius:14px;padding:14px;margin:12px 0;box-shadow:0 8px 24px #0004}.muted{color:#94a3b8}.jobs{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:12px}.job{border:1px solid #334155;border-radius:12px;padding:12px;background:#0b1020}.job.error{border-color:#ef4444}.job.warning{border-color:#f59e0b}.job.completed{border-color:#22c55e}.job.canceled{border-color:#94a3b8;opacity:.9}.job-head{display:flex;justify-content:space-between;gap:10px}.pill{display:inline-block;border-radius:999px;background:#1f2937;padding:2px 8px;font-size:12px;font-weight:700}.platform-bili{background:#b45309}.platform-douyin{background:#7c3aed}.bar{height:10px;background:#1f2937;border-radius:999px;overflow:hidden;margin:10px 0}.fill{height:10px;background:linear-gradient(90deg,#38bdf8,#22c55e)}pre{white-space:pre-wrap;background:#030712;border-radius:8px;padding:8px;max-height:95px;overflow:auto}.small{font-size:13px}.warn{color:#fbbf24}.ok{color:#86efac}.bad{color:#fca5a5}.statgrid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.stat{background:#0b1020;border:1px solid #263244;border-radius:10px;padding:12px}.stat b{font-size:24px}.section-head{display:flex;justify-content:space-between;align-items:center;margin-top:18px}.badge{border-radius:999px;background:#334155;padding:3px 9px;font-size:12px;font-weight:700}.empty{border:1px dashed #334155;border-radius:12px;padding:16px;background:#0b1020}.channel{border-bottom:1px solid #263244;padding:10px 0}.channel:last-child{border-bottom:0}.channel a,.link{color:#67e8f9;text-decoration:none}.copy{float:right;color:#93c5fd;cursor:pointer}.tablewrap{overflow:auto;border:1px solid #263244;border-radius:12px}.episodes{width:100%;border-collapse:collapse;min-width:860px}.episodes th,.episodes td{border-bottom:1px solid #263244;padding:9px;text-align:left;vertical-align:top}.episodes th{position:sticky;top:0;background:#111827}.episodes tr:hover{background:#0b1224}.btn{background:#1d4ed8;color:white;border:0;border-radius:9px;padding:8px 11px;cursor:pointer;font-weight:700}.btn:hover{filter:brightness(1.15)}.btn.secondary{background:#334155}.btn.danger{background:#991b1b}.btn.good{background:#15803d}.btn:disabled{opacity:.5;cursor:not-allowed}.formgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px}.formgrid label{display:flex;flex-direction:column;gap:5px}.formgrid input,.formgrid select,.formgrid textarea,.filter{background:#0b1020;border:1px solid #334155;color:#e5e7eb;border-radius:9px;padding:9px}.actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.tabs{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}.tab{background:#0b1020;border:1px solid #334155;color:#e5e7eb;border-radius:999px;padding:8px 12px;cursor:pointer}.tab.active{background:#1d4ed8;border-color:#60a5fa}.series-card{border:1px solid #334155;border-radius:12px;padding:12px;background:#0b1020;margin:12px 0}.series-title{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.notice{background:#451a03;border:1px solid #92400e;color:#fde68a;border-radius:10px;padding:10px;margin:8px 0}.jobbox{background:#030712;border-radius:10px;padding:10px;margin-top:8px}.nowrap{white-space:nowrap}.timeline{text-align:right;font-size:12px;color:#94a3b8}@media(max-width:720px){.statgrid{grid-template-columns:repeat(2,1fr)}body{padding:10px}.series-title{display:block}.copy{float:none}}
.fill{height:100%}.compilation-frame{display:block;max-width:100%;max-height:260px;border:1px solid #334155;border-radius:8px;margin:8px 0}</style></head><body>
<div class="top"><div><h1>OpenClaw Local Dashboard</h1><div id="stamp" class="muted">Đang tải...</div></div><div class="pill" id="proc">process: ?</div></div>
<div class="card"><b>Output root:</b> <span id="root"></span><br><span class="muted">Tự refresh mỗi 3 giây. Bilibili có khu riêng bên dưới; job xếp từ mới đến cũ trong 4 ngày gần nhất.</span></div>
<div class="card"><div id="stats" class="statgrid"></div></div>
<div class="tabs"><button class="tab active" data-view="series">Series Bilibili</button><button class="tab" data-view="voices">Voice Manager</button><button class="tab" data-view="status">Job/Monitor</button></div>
<section id="view-series">
  <div class="card">
    <div class="section-head"><h2>Series phim Bilibili</h2><span class="badge" id="series-count">0 series</span></div>
    <p class="muted">Quản lý bằng chuột: thêm series/kênh, refresh tập thật từ Chrome CDP/trang gốc, mở link tập, chọn giọng và bấm tải/lồng tiếng. Không dùng AI đoán tập.</p>
    <div class="formgrid">
      <label>Tên series<input id="series-name" placeholder="墨然DMW / 邪神墨然"></label>
      <label>Keyword<input id="series-keyword" placeholder="邪神墨然"></label>
      <label>Link video/series gốc Bilibili<input id="series-source" placeholder="https://www.bilibili.com/video/BV..."></label>
      <label>Link kênh/space tùy chọn<input id="series-channel" placeholder="https://space.bilibili.com/..."></label>
    </div>
    <div class="actions" style="margin-top:10px"><button class="btn good" onclick="addSeries()">Thêm series</button><button class="btn secondary" onclick="loadSeries(true)">Refresh danh sách</button><input class="filter" id="series-filter" oninput="renderSeries()" placeholder="Lọc tên/tập/link..."><label class="actions">Giọng <select id="series-voice" class="filter"><!-- VOICE_OPTIONS --></select></label><label class="actions">AI model <select id="ai-model" class="filter"><option value="ollama/minimax-m3:cloud" selected>9router Ollama MiniMax M3 cloud - lồng tiếng + vision</option><option value="ollama/kimi-k2.7-code:cloud">9router Ollama Kimi K2.7 Code cloud - fallback JSON/logic</option><option value="ollama/glm-5.2:cloud">9router Ollama GLM 5.2 cloud - fallback nhanh</option><option value="ollama">9router Ollama combo fallback</option><option value="kr/oc/deepseek-v4-flash-free">kr/oc/deepseek-v4-flash-free</option><option value="oc/deepseek-v4-flash-free">oc/deepseek-v4-flash-free</option><option value="combo3in1">combo3in1</option></select></label><label class="actions">Nhạc nền <select id="bgm-mode" class="filter"><option value="auto">Tự động chọn nhạc nền</option><option value="duck">Giữ nhạc nền thông minh</option><option value="none">Tắt nhạc nền</option></select></label></div>
    <div class="series-card" style="margin-top:16px"><div class="section-head"><h3>Compilation planner</h3><span class="badge">Plan trước khi chạy</span></div><p class="muted small">Tạo compilation theo thứ tự nguồn. Runner tự khóa state/output root; dashboard không nhận đường dẫn hoặc vùng overlay thủ công.</p><div class="formgrid"><label>Compilation ID<input id="compilation-id" placeholder="my-series-compilation"></label><label>Series ID<input id="compilation-series-id" placeholder="ID series (tùy chọn)"></label><label>Giọng series<select id="compilation-voice"><!-- VOICE_OPTIONS --></select></label><label>Selector<select id="compilation-selector" onchange="updateCompilationSelectorDetail()"><option value="all">all</option><option value="range">range</option><option value="list">list</option><option value="latest">latest</option><option value="unprocessed">unprocessed</option></select></label><label id="compilation-selector-detail-label">Range/list/latest count<input id="compilation-selector-detail" placeholder="1-3, 1,2,4 hoặc số latest (ví dụ 5)"></label><label>Max duration (seconds)<input id="compilation-max-seconds" type="number" min="1" max="5400" value="5400"></label></div><div class="actions" style="margin-top:10px"><label><input id="branding-blur-logo" type="checkbox" checked> Blur logo</label><label><input id="branding-blur-title" type="checkbox" checked> Blur title</label><label><input id="branding-replace-logo" type="checkbox" checked> Replace logo</label><label><input id="include-branding" type="checkbox"> Thêm thương hiệu Cáo Một Phim (intro + outro)</label></div><div class="notice small">Bilibili: tự động che toàn bộ cụm chữ uploader tiếng Trung ở góc trên trái cùng dấu bilibili và thay bằng logo tròn. Vùng phát hiện chỉ hiển thị để theo dõi.</div><div class="actions"><button class="btn" onclick="planCompilation()">Plan preview</button><button id="compilation-run" class="btn good" onclick="runCompilation()" disabled>Run compilation</button><button class="btn secondary" onclick="compilationAction('status')">Status</button><button class="btn secondary" onclick="compilationAction('resume')">Resume</button><button class="btn danger" onclick="compilationAction('cancel')">Cancel</button></div><div id="compilation-msg" class="small muted" style="margin-top:8px"></div><pre id="compilation-preview" class="small" style="display:none"></pre></div>
    <div id="compilation-detections" class="small" style="margin-top:10px"></div><div id="series-msg" class="small muted" style="margin-top:8px"></div>
    <div id="series-list"></div>
  </div>
</section>
<section id="view-voices" style="display:none">
  <div class="card">
    <div class="section-head"><h2>Voice Manager</h2><span class="badge" id="voice-count">0 giọng</span></div>
    <div class="formgrid">
      <label>Link giọng AI33 hoặc Voice ID<input id="voice-id" placeholder="Dán link AI33 hoặc vbee_hn_female_maiphuong_vdts_48k-fhg"></label>
      <label>Tên hiển thị<input id="voice-label" placeholder="Mai Phương - Vbee"></label>
      <label>Alias<input id="voice-aliases" placeholder="maiphuong, vbee"></label>
      <label>Test text<input id="voice-test-text" maxlength="160" placeholder="Xin chào, đây là bản thử giọng."></label>
    </div>
    <div class="actions" style="margin-top:10px"><label class="actions"><input type="checkbox" id="voice-set-default"> Đặt làm mặc định</label><button class="btn secondary" onclick="pasteVoiceLink()">Dán link</button><button class="btn good" onclick="saveVoice()">Thêm giọng</button><button class="btn secondary" onclick="restoreVoices()">Khôi phục bản trước</button></div>
    <div id="voice-msg" class="small muted" style="margin-top:8px"></div>
    <div id="voice-list" class="tablewrap" style="margin-top:12px"></div>
    <audio id="voice-audio" controls style="display:none;margin-top:12px;width:100%"></audio>
  </div>
</section>
<section id="view-status" style="display:none">
  <div class="card"><div class="actions"><label class="actions">Giọng khi chạy lại <select id="status-voice" class="filter"><!-- VOICE_OPTIONS --></select></label><span class="small muted">Dùng cho nút “Chạy tiếp từ job cũ” và “Chạy lại video từ đầu” trong tab này.</span></div></div>
  <div class="section-head"><h2>Kênh đang theo dõi</h2><span class="badge" id="channel-count">0 kênh</span></div><div class="card" id="channels"></div>
  <div class="section-head"><h2>Bilibili</h2><span class="badge platform-bili" id="bili-count">0 job</span></div><div id="bili-empty" class="empty">Chưa có job Bilibili trong 4 ngày gần nhất. Khi anh yêu cầu OpenClaw tải Bilibili, tiến trình sẽ hiện ở đây.<pre>/home/node/host-bin/openclaw-call-host-runner.sh bilibili-find "từ khóa" 10
/home/node/host-bin/openclaw-call-host-runner.sh run-bilibili "https://www.bilibili.com/video/BV..." nam</pre></div><div id="bili-jobs" class="jobs"></div>
  <div class="section-head"><h2>Douyin / Video khác</h2><span class="badge" id="douyin-count">0 job</span></div><div id="douyin-jobs" class="jobs"></div>
</section>
<script>
let SERIES=[];let SERIES_JOBS={};let DASH_JOBS=[];let VOICE_STATE={voices:[],default_voice:'',voice_options_html:''};let VOICE_LOADED=false;
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function cls(state){return state==='error'?'error':state==='warning'?'warning':state==='completed'?'completed':state==='canceled'?'canceled':''}
function friendlyError(code){const m={TTSAI33Failed:'Lồng tiếng AI33 lỗi — kiểm tra API key/kết nối/credit.',AI33AuthMissing:'Thiếu AI33_API_KEY. Thiết lập env rồi chạy lại.',AI33AuthFailed:'AI33 API key không hợp lệ hoặc hết hạn (401/403).',AI33QuotaFailed:'AI33 hết credit hoặc bị rate-limit (429).',AI33Timeout:'AI33 sinh giọng quá thời gian.',AI33NoAudioUrl:'AI33 tạo task nhưng không sinh được audio — thử voice khác hoặc kiểm tra credit.',TTSResonaFailed:'Lồng tiếng Resona lỗi — kiểm tra token/kết nối/credit.',ResonaAuthMissing:'Thiếu token Resona. Thiết lập env RESONA_API_TOKEN rồi chạy lại.',ResonaAuthFailed:'Token Resona không hợp lệ hoặc hết hạn (401/403).',ResonaQuotaFailed:'Resona hết credit hoặc bị rate-limit (429).',ResonaTextTooShort:'Có cue quá ngắn cho Resona và policy=fail.',ResonaTextTooShortUngroupable:'Cue quá ngắn và không gom được đủ credit Resona — thử lại hoặc dán transcript_vi.json.',ResonaCoverageTooLow:'Pipeline chưa dùng đủ giọng Resona, nhiều cue bị bypass/fallback.',ResonaTimeout:'Resona sinh giọng quá thời gian.',ResonaNoAudioUrl:'Resona tạo request nhưng không sinh được audio — thử voice khác như Nữ Tuệ An.',KokoroTTSFailed:'Kokoro sinh giọng lỗi — kiểm tra runtime/model/voice.',KokoroVoiceInvalid:'Giọng Kokoro không hợp lệ.',TTSAllSilence:'TTS rơi silence toàn bộ — kiểm tra Kokoro/Resona/Edge/9router.',VoiceSyncFail:'Giọng Việt không khớp timeline (quá ngắn hoặc quá dài).'};return m[code]||''}
function platformLabel(j){let u=String(j.source_url||'');let p=(j.platform||'').toLowerCase();if(p==='bilibili'||u.includes('bilibili.com'))return '<span class="pill platform-bili">Bilibili</span>';if(p==='douyin'||u.includes('douyin.com'))return '<span class="pill platform-douyin">Douyin</span>';return '<span class="pill">local</span>'}
function renderChannels(channels){if(!channels.length)return '<span class="muted">Chưa có kênh monitor.</span>';return channels.map(c=>`<div class="channel"><span class="pill">#${c.index}</span> <span class="pill ${c.platform==='Bilibili'?'platform-bili':'platform-douyin'}">${esc(c.platform)}</span> <b>${esc(c.name)}</b><span class="copy" onclick="navigator.clipboard.writeText('${esc(c.copy_text)}')">copy: tên + URL</span><br><span class="small muted">Thêm: ${esc(c.added_at||'-')}</span><br><a href="${esc(c.url)}" target="_blank" rel="noopener noreferrer">${esc(c.url)}</a></div>`).join('')}
function voiceDefault(){return VOICE_STATE.default_voice||'ai33:vbee_hn_female_maiphuong_vdts_48k-fhg'}
function voiceMsg(text,kind='muted'){const el=document.getElementById('voice-msg');if(el){el.className='small '+kind;el.textContent=text||''}}
function voiceOptionsFromState(){return VOICE_STATE.voice_options_html||document.getElementById('series-voice')?.innerHTML||''}
function refreshVoiceSelects(forceDefault=false){const html=voiceOptionsFromState();const fallback=voiceDefault();['series-voice','compilation-voice','status-voice'].forEach(id=>{const el=document.getElementById(id);if(!el||!html)return;const prev=el.value;el.innerHTML=html;el.value=forceDefault?fallback:(prev||fallback);if(!el.value)el.value=fallback})}
function renderVoices(){const voices=VOICE_STATE.voices||[];document.getElementById('voice-count').textContent=voices.length+' giọng';let rows=voices.map(v=>{const c=v.canonical_voice||('ai33:'+v.voice_id);const isDef=c===VOICE_STATE.default_voice;return `<tr><td>${isDef?'<span class="pill platform-douyin">default</span> ':''}<b>${esc(v.label||v.voice_id)}</b><div class="small muted">${esc(c)}</div></td><td>${esc((v.aliases||[]).join(', '))}</td><td>${esc(v.timing_profile||'-')}<div class="small muted">min slow ${esc(v.min_slow_ratio??'-')}</div></td><td>${v.enabled===false?'<span class="pill">off</span>':'<span class="pill completed">on</span>'}</td><td class="actions nowrap"><button class="btn secondary" onclick="setDefaultVoice('${esc(c)}')">Đặt mặc định</button><button class="btn secondary" onclick="testVoice('${esc(c)}')">Test giọng</button><button class="btn danger" onclick="disableVoice('${esc(c)}')">Tắt</button></td></tr>`}).join('');document.getElementById('voice-list').innerHTML=`<table class="episodes"><thead><tr><th>Giọng</th><th>Alias</th><th>Timing</th><th>Trạng thái</th><th>Thao tác</th></tr></thead><tbody>${rows||'<tr><td colspan="5" class="muted">Chưa có voice registry.</td></tr>'}</tbody></table>`}
async function loadVoices(){try{const oldDefault=VOICE_STATE.default_voice||'';const r=await fetch('/api/voices',{cache:'no-store'});const d=await r.json();if(!d.ok)throw new Error(d.error||'Không tải được voice registry');VOICE_STATE=d;const forceDefault=!VOICE_LOADED||(oldDefault&&d.default_voice&&oldDefault!==d.default_voice);VOICE_LOADED=true;renderVoices();refreshVoiceSelects(forceDefault)}catch(e){voiceMsg('Lỗi voice registry: '+e,'bad')}}
async function pasteVoiceLink(){try{const text=await navigator.clipboard.readText();document.getElementById('voice-id').value=text;voiceMsg('Đã dán link/ID. Bấm Thêm giọng để lưu vào pipeline.','ok')}catch(e){voiceMsg('Không đọc được clipboard, dán tay vào ô đầu tiên.','bad')}}
async function saveVoice(){try{voiceMsg('Đang thêm giọng vào registry/pipeline...');const input=document.getElementById('voice-id').value;const payload={voice_input:input,voice_url:input,voice_id:input,label:document.getElementById('voice-label').value,aliases:document.getElementById('voice-aliases').value,set_default:document.getElementById('voice-set-default').checked};const d=await apiPost('/api/voices',payload);await loadVoices();voiceMsg(d.warning||'Đã thêm giọng vào pipeline. Lưu không gọi AI33 TTS.','ok')}catch(e){voiceMsg('Lỗi thêm giọng: '+e,'bad')}}
async function setDefaultVoice(voice){try{voiceMsg('Đang đặt mặc định...');const d=await apiPost('/api/voices/default',{voice});await loadVoices();voiceMsg(d.warning||'Đã đặt mặc định.','ok')}catch(e){voiceMsg('Lỗi đặt mặc định: '+e,'bad')}}
async function disableVoice(voice){try{if(!confirm('Tắt giọng này khỏi registry?'))return;voiceMsg('Đang tắt giọng...');await apiPost('/api/voices/disable',{voice});await loadVoices();voiceMsg('Đã tắt giọng.','ok')}catch(e){voiceMsg('Lỗi tắt giọng: '+e,'bad')}}
async function restoreVoices(){try{if(!confirm('Khôi phục bản backup registry gần nhất?'))return;voiceMsg('Đang khôi phục...');await apiPost('/api/voices/restore',{});await loadVoices();voiceMsg('Đã khôi phục registry.','ok')}catch(e){voiceMsg('Lỗi khôi phục: '+e,'bad')}}
async function testVoice(voice){try{if(!confirm('Test giọng sẽ gọi AI33 TTS và tốn credit. Tiếp tục?'))return;voiceMsg('Đang test giọng AI33...');const d=await apiPost('/api/voices/test',{voice,text:document.getElementById('voice-test-text').value});const audio=document.getElementById('voice-audio');audio.src=d.audio_url;audio.style.display='block';audio.play().catch(()=>{});voiceMsg('Test OK '+(d.duration_ms||0)+'ms · '+(d.cached?'cache':'new'),'ok')}catch(e){voiceMsg('Lỗi test giọng: '+e,'bad')}}
function isStuckJob(j){return ['StuckHeartbeat','NoHeavyProcess','No9RouterCall'].includes(j.error_code||'')||String(j.error_message||'').includes('Đang bị treo')}
function currentBgmMode(){return document.getElementById('bgm-mode')?.value||'auto'}
function currentAiModel(){return document.getElementById('ai-model')?.value||'ollama/minimax-m3:cloud'}
function currentRetryVoice(j){const statusVoice=document.getElementById('status-voice')?.value;const seriesVoice=document.getElementById('series-voice')?.value;return statusVoice||seriesVoice||j?.voice||voiceDefault()}
function retryButtons(j,i){let buttons='';let canResume=j.job_dir&&(j.state==='error'||j.state==='warning'||j.state==='canceled'||isStuckJob(j)||j.translate_pending);let canRerun=j.source_url&&(j.state==='error'||j.state==='warning'||j.state==='canceled');if((j.state==='queued'||j.state==='running'||j.state==='warning')&&j.state!=='canceled'){buttons+=`<button class="btn danger" onclick="cancelJob(${i})">Dừng video</button>`}if(j.final_video){buttons+=`<button class="btn good" onclick="retryJob(${i},'thumbnail')">Thử lại thumbnail</button>`}if(canResume){buttons+=`<button class="btn good" onclick="retryJob(${i},'resume')">Chạy tiếp từ job cũ</button>`}if(canRerun){buttons+=`<button class="btn secondary" onclick="retryJob(${i},'pipeline')">Chạy lại video từ đầu</button>`}return buttons?`<div class="actions" style="margin:8px 0">${buttons}</div>`:''}
async function retryJob(i,mode){try{const j=DASH_JOBS[i];if(!j)throw new Error('Không thấy job');const voice=currentRetryVoice(j);const label=mode==='thumbnail'?'thumbnail':(mode==='resume'?'chạy tiếp job cũ':'pipeline video từ đầu');msg('Đang gửi lệnh '+label+'...');const d=await apiPost('/api/job/retry',{mode,job_dir:j.job_dir,source_url:j.source_url,platform:j.platform,voice,bgm_mode:currentBgmMode(),model:currentAiModel()});msg('Đã bắt đầu '+label+' (pid '+(d.pid||'-')+'). Log: '+(d.log_path||''),'ok')}catch(e){msg('Lỗi thử lại: '+e,'bad')}}
async function cancelJob(i){try{const j=DASH_JOBS[i];if(!j)throw new Error('Không thấy job');if(!confirm('Dừng job video này?'))return;msg('Đang dừng video...');const d=await apiPost('/api/job/cancel',{id:j.id,job_dir:j.job_dir,request_path:j.request_path,source_url:j.source_url});await load();await loadSeries();msg('Đã gửi lệnh dừng video. Đã kill '+((d.killed||[]).length)+' process.','ok')}catch(e){msg('Lỗi dừng video: '+e,'bad')}}
function fmtSeconds(v){let n=Number(v);return Number.isFinite(n)?n.toFixed(3).replace(/\.?0+$/,'')+'s':''}
function timelineHtml(r){if(!r)return '';let master=fmtSeconds(r.master_duration??r.input_video_duration??r.input_duration);let out=fmtSeconds(r.output_video_duration);let audio=fmtSeconds(r.output_audio_duration);let parts=[];if(master)parts.push('master '+master);if(out)parts.push('out '+out);if(audio)parts.push('audio '+audio);let klass=r.duration_check_passed===false?'warn':'muted';return parts.length?`<div class="small ${klass}">Timeline: ${parts.join(' / ')}</div>`:''}
function voiceUsedHtml(j){const r=j.voice_sync_report||{};const label=r.voice_label||'';const canonical=r.canonical_voice||'';const used=r.ai33_voice_used||r.voice_id||'';if(!label&&!canonical&&!used)return '';return `<div class="small ok">Giọng dùng thật: ${esc(label||canonical||used)}${canonical?` · ${esc(canonical)}`:''}</div>`}
function renderJob(j,i){let pct=Math.max(0,Math.min(100,j.progress_percent||0));let stuck=isStuckJob(j)?`<div class="small bad"><b>Đang bị treo</b>: ${esc(j.error_message||'Job không còn heartbeat/process xử lý.')}</div>`:'';let friendly=friendlyError(j.error_code);let warn=j.error_code?`<div class="small bad"><b>${esc(j.error_code)}</b>${friendly?` — ${friendly}`:''}<br>${esc(j.error_message||'')}</div>`:'';let tl=timelineHtml(j.timeline_report);let fitWarn=j.fit_adjustments&&((Number(j.fit_adjustments.segments_adjusted)||0)>0||(Number(j.fit_adjustments.overflow_segments)||0)>0);let fit=j.fit_adjustments?`<div class="small ${fitWarn?'warn':'muted'}">BGM: ${esc(j.fit_adjustments.bgm_mode_selected||'-')} · Đã tự chỉnh ${j.fit_adjustments.segments_adjusted||0} đoạn · Tràn ${j.fit_adjustments.overflow_segments||0} đoạn</div>`:'';let pending=j.translate_pending?`<div class="notice"><b>Pipeline chưa tạo được bản dịch tự động</b><br>Bấm “Chạy tiếp từ job cũ” để pipeline tự dịch lại (không cần dán tay). Nếu vẫn lỗi, có thể dán <code>transcript_vi.json</code> rồi bấm tiếp.</div>`:'';let thumb=j.thumbnail_status?`<div class="small warn">Thumbnail Flow: ${esc(j.thumbnail_status.reason||j.thumbnail_status.status)}</div>`:'';let bridge=j.thumbnail_bridge_status?`<div class="small ok">Flow bridge: ${esc(j.thumbnail_bridge_status.phase||'-')} — ${esc(j.thumbnail_bridge_status.status||'-')} (${Math.max(0,Math.min(100,j.thumbnail_bridge_status.progress_percent||0))}%)</div>`:'';return `<div class="job ${cls(j.state)}"><div class="job-head"><div><span class="pill">#${i+1}</span> <span class="pill">${esc(j.state)}</span> ${platformLabel(j)}<br><b>${esc(j.id)}</b></div><div class="timeline">${esc(j.day_label||j.updated_at||'-')}<br><span class="muted">mới → cũ</span></div></div><div class="bar"><div class="fill" style="width:${pct}%"></div></div><div><b>${pct}%</b> — ${esc(j.phase_label_vi)} <span class="muted">(${esc(j.phase)})</span></div><div class="small muted">Tạo: ${esc(j.created_at||'-')} | Cập nhật: ${esc(j.updated_at||'-')} | Không update: ${j.age_seconds||0}s</div>${stuck}${warn}${pending}${tl}${voiceUsedHtml(j)}${fit}${thumb}${bridge}${retryButtons(j,i)}<div class="small"><b>Nền tảng:</b> ${esc(j.platform||'-')} ${j.source_title?`— ${esc(j.source_title)}`:''}</div><div class="small">Source: ${esc(j.source_url||'-')}</div><div class="small">Video: ${j.final_video?esc(j.final_video):'-'}</div><div class="small">Thumbnail: ${j.thumbnail?esc(j.thumbnail):'-'}</div><pre>${esc(j.last_log_line||'')}</pre><div class="small muted">Log: ${esc(j.log_path||j.request_path||'')}</div></div>`}
function setView(view){if(!['series','voices','status'].includes(view))view='series';document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.view===view));document.getElementById('view-series').style.display=view==='series'?'block':'none';document.getElementById('view-voices').style.display=view==='voices'?'block':'none';document.getElementById('view-status').style.display=view==='status'?'block':'none';if(location.hash.slice(1)!==view)history.replaceState(null,'','#'+view)}
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>setView(b.dataset.view));
window.addEventListener('hashchange',()=>setView(location.hash.slice(1)||'series'));
async function apiPost(path,payload){const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload||{})});const d=await r.json();if(!d.ok)throw new Error(d.error||d.stderr||'API lỗi');return d}
let COMPILATION_PLAN_READY=false;
function compilationMsg(text,kind='muted'){const el=document.getElementById('compilation-msg');el.className='small '+kind;el.textContent=text||''}
function updateCompilationSelectorDetail(){const kind=document.getElementById('compilation-selector').value;const label=document.getElementById('compilation-selector-detail-label');const detail=document.getElementById('compilation-selector-detail');label.firstChild.textContent=kind==='latest'?'Latest count':'Range/list/latest count';detail.placeholder=kind==='latest'?'Số tập latest (ví dụ 5)':'1-3, 1,2,4 hoặc số latest (ví dụ 5)'}
function compilationPayload(){const id=document.getElementById('compilation-id').value.trim();if(!id)throw new Error('Nhập Compilation ID');const kind=document.getElementById('compilation-selector').value;const detail=document.getElementById('compilation-selector-detail').value.trim();let selector=kind;if(kind==='range'||kind==='list'){if(!detail)throw new Error('Nhập range/list selector');selector=kind+':'+detail}else if(kind==='latest'&&detail){selector='latest:'+detail}const includeBranding=document.getElementById('include-branding').checked;return {compilation_id:id,series_id:document.getElementById('compilation-series-id').value.trim(),voice:document.getElementById('compilation-voice').value,selector,max_seconds:document.getElementById('compilation-max-seconds').value,order:'source',split_episodes:false,include_intro:includeBranding,include_outro:includeBranding,branding:{blur_logo:document.getElementById('branding-blur-logo').checked,blur_title:document.getElementById('branding-blur-title').checked,replace_logo:document.getElementById('branding-replace-logo').checked}}}
function showCompilationResult(d){const preview=document.getElementById('compilation-preview');preview.textContent=JSON.stringify(d,null,2);preview.style.display='block'}
function renderCompilationDetections(d){const box=document.getElementById('compilation-detections');const records=d?.overlay_detections||d?.manifest?.overlay_detections||{};const list=Array.isArray(records)?records:Object.entries(records).map(([episode_number,v])=>({...v,episode_number}));if(!list.length){box.innerHTML='<div class="notice">needs_attention: Không xác định được layout hoặc phát hiện overlay thất bại.</div>';return}box.innerHTML=list.map((x,i)=>{const previews=x.previews||x.sampled_frame_previews||[];const first=previews[0];const src=first?`/api/compilation/preview?compilation_id=${encodeURIComponent(document.getElementById('compilation-id').value.trim())}&episode=${encodeURIComponent(x.episode_number??'')}&index=0`:'';const regions=JSON.stringify(x.regions||[],null,2);return `<div class="jobbox"><b>Tập ${esc(x.episode_number??'—')}</b> · <span class="pill">${esc(x.state||'unknown')}</span><div class="small muted">${esc(typeof x.diagnostics==='string'?x.diagnostics:(x.diagnostics?.reason||''))}</div>${src?`<img class="compilation-frame" data-compilation-preview data-id="${i}" src="${src}" alt="Preview tập ${esc(x.episode_number??'')}" loading="lazy">`: '<div class="notice small">needs_attention: Không xác định được layout hoặc không tạo được preview frame.</div>'}<div class="actions small"><button class="btn secondary" onclick="cycleCompilationPreview(${i},${Number(x.episode_number)||0},${previews.length})">Prev/next preview</button><span id="compilation-preview-label-${i}">${previews.length?`1/${previews.length}`:'0/0'}</span></div><div class="small">Detected regions (read-only)</div><pre>${esc(regions)}</pre></div>`}).join('')}
function cycleCompilationPreview(card,episode,count){if(!count)return;const img=document.querySelector(`img[data-compilation-preview][data-id="${card}"]`);if(!img)return;const next=(Number(img.dataset.index||0)+1)%count;img.dataset.index=next;img.src=`/api/compilation/preview?compilation_id=${encodeURIComponent(document.getElementById('compilation-id').value.trim())}&episode=${encodeURIComponent(episode)}&index=${next}`;document.getElementById('compilation-preview-label-'+card).textContent=`${next+1}/${count}`}
async function planCompilation(){try{COMPILATION_PLAN_READY=false;document.getElementById('compilation-run').disabled=true;compilationMsg('Đang tạo plan preview...');const d=await apiPost('/api/compilation/plan',compilationPayload());showCompilationResult(d);renderCompilationDetections(d);COMPILATION_PLAN_READY=true;document.getElementById('compilation-run').disabled=false;compilationMsg('Plan sẵn sàng. Kiểm tra parts/missing/warnings trước khi Run.','ok')}catch(e){compilationMsg('Lỗi plan: '+e,'bad')}}
async function runCompilation(){if(!COMPILATION_PLAN_READY){compilationMsg('Cần Plan preview trước khi chạy.','warn');return}try{compilationMsg('Đang gửi lệnh chạy compilation...');const d=await apiPost('/api/compilation/run',{compilation_id:document.getElementById('compilation-id').value.trim()});showCompilationResult(d);compilationMsg('Đã gửi lệnh run.','ok')}catch(e){compilationMsg('Lỗi run: '+e,'bad')}}
async function compilationAction(action){try{const id=document.getElementById('compilation-id').value.trim();if(!id)throw new Error('Nhập Compilation ID');if(action==='cancel'&&!confirm('Hủy compilation này?'))return;compilationMsg('Đang '+action+' compilation...');const d=await apiPost('/api/compilation/'+action,{compilation_id:id});showCompilationResult(d);compilationMsg('Compilation '+action+' đã cập nhật.','ok')}catch(e){compilationMsg('Lỗi '+action+': '+e,'bad')}}
function msg(text,kind='muted'){document.getElementById('series-msg').className='small '+kind;document.getElementById('series-msg').textContent=text||''}
function durationText(v){if(!v)return '—';let n=Number(v);if(!Number.isFinite(n))return String(v);let m=Math.floor(n/60),s=Math.floor(n%60);return `${m}:${String(s).padStart(2,'0')}`}
async function loadSeries(showMsg=false){try{if(showMsg)msg('Đang tải danh sách series...');const r=await fetch('/api/series/list',{cache:'no-store'});const d=await r.json();if(!d.ok)throw new Error(d.error||'Không tải được series');SERIES=d.series||[];renderSeries();if(showMsg)msg('Đã cập nhật danh sách series','ok')}catch(e){msg('Lỗi series: '+e,'bad')}}
function renderSeries(){const q=(document.getElementById('series-filter')?.value||'').toLowerCase();document.getElementById('series-count').textContent=SERIES.length+' series';let html='';for(const s of SERIES){const episodes=s.episodes||[];const text=JSON.stringify([s.name,s.keyword,s.source_url,s.channel_url,episodes.map(e=>[e.episode_number,e.title,e.url])]).toLowerCase();if(q&&!text.includes(q))continue;html+=`<div class="series-card"><div class="series-title"><div><h3>${esc(s.name||s.series_id)}</h3><div class="small muted">ID: ${esc(s.series_id)} · Keyword: ${esc(s.keyword||'-')} · ${episodes.length} tập · Refresh: ${esc(s.last_refresh_at||'chưa có')}</div>${s.last_error?`<div class="notice">${esc(s.last_error)}</div>`:''}</div><div class="actions">${s.channel_url?`<a class="btn secondary" href="${esc(s.channel_url)}" target="_blank" rel="noopener noreferrer">Mở kênh</a>`:''}${s.source_url?`<a class="btn secondary" href="${esc(s.source_url)}" target="_blank" rel="noopener noreferrer">Mở nguồn</a>`:''}<button class="btn" onclick="refreshSeries('${esc(s.series_id)}')">Refresh tập</button></div></div><div class="tablewrap"><table class="episodes"><thead><tr><th>Tập</th><th>Tiêu đề</th><th>Duration</th><th>Status</th><th>Thao tác</th></tr></thead><tbody>${episodes.map(e=>renderEpisode(s,e)).join('')}</tbody></table></div></div>`}document.getElementById('series-list').innerHTML=html||'<div class="empty">Chưa có series nào. Nhập thông tin phía trên rồi bấm “Thêm series”.</div>'}
function renderEpisode(s,e){const job=e.last_job_id||'';const st=job?(SERIES_JOBS[job]?.status||e.status||'queued'):(e.status||'ready');return `<tr><td class="nowrap"><b>${esc(e.episode_number??'—')}</b></td><td>${esc(e.title||'[Không tiêu đề]')}<div class="small muted">${esc(e.source||'')}</div>${job?`<div class="jobbox small">Job: ${esc(job)}<br>Status: ${esc(st)}${SERIES_JOBS[job]?.log_tail?`<pre>${esc(SERIES_JOBS[job].log_tail)}</pre>`:''}</div>`:''}</td><td>${durationText(e.duration)}</td><td>${esc(st)}</td><td class="actions nowrap">${e.url?`<a class="btn secondary" href="${esc(e.url)}" target="_blank" rel="noopener noreferrer">Mở link</a><button class="btn good" onclick="downloadEpisode('${esc(s.series_id)}',${Number(e.episode_number)})">Tải + lồng tiếng</button>`:''}${job?`<button class="btn secondary" onclick="jobStatus('${esc(job)}')">Status</button><button class="btn danger" onclick="cancelJobById('${esc(job)}')">Dừng</button>`:''}</td></tr>`}
async function cancelJobById(jobId){try{if(!confirm('Dừng job '+jobId+'?'))return;msg('Đang dừng job '+jobId+'...');const d=await apiPost('/api/job/cancel',{id:jobId,job_id:jobId});await load();await loadSeries();msg('Đã gửi lệnh dừng '+jobId+'. Đã kill '+((d.killed||[]).length)+' process.','ok')}catch(e){msg('Lỗi dừng video: '+e,'bad')}}
async function addSeries(){try{msg('Đang thêm series...');const payload={name:document.getElementById('series-name').value,keyword:document.getElementById('series-keyword').value,source_url:document.getElementById('series-source').value,channel_url:document.getElementById('series-channel').value};await apiPost('/api/series/add',payload);document.getElementById('series-name').value='';document.getElementById('series-keyword').value='';document.getElementById('series-source').value='';document.getElementById('series-channel').value='';await loadSeries();msg('Đã thêm series. Bấm Refresh tập để quét trang gốc.','ok')}catch(e){msg('Lỗi thêm series: '+e,'bad')}}
async function refreshSeries(id){try{msg('Đang refresh tập từ Chrome CDP/trang gốc...');await apiPost('/api/series/refresh',{series_id:id,limit:100});await loadSeries();msg('Đã refresh tập thật từ nguồn gốc','ok')}catch(e){msg('Lỗi refresh: '+e,'bad');await loadSeries()}}
async function downloadEpisode(seriesId,episodeNumber){try{const voice=document.getElementById('series-voice').value||voiceDefault();const bgm_mode=currentBgmMode();const ninerouter_model=currentAiModel();msg('Đang queue tải/lồng tiếng...');const d=await apiPost('/api/series/download',{series_id:seriesId,episode_numbers:[episodeNumber],voice,bgm_mode,ninerouter_model});if(d.job_id)SERIES_JOBS[d.job_id]={job_id:d.job_id,status:'queued'};await loadSeries();msg('Đã queue job '+(d.job_id||'')+' · model '+ninerouter_model,'ok')}catch(e){msg('Lỗi tải/lồng tiếng: '+e,'bad')}}
async function jobStatus(jobId){try{const d=await apiPost('/api/series/job-status',{job_id:jobId});SERIES_JOBS[jobId]=d;renderSeries();msg('Đã cập nhật job '+jobId,'ok')}catch(e){msg('Lỗi status: '+e,'bad')}}
async function load(){try{const r=await fetch('/api/status',{cache:'no-store'});const d=await r.json();const jobs=d.jobs||[];DASH_JOBS=jobs;const channels=d.monitor_channels||[];const bili=jobs.filter(j=>(j.platform||'').toLowerCase()==='bilibili'||String(j.source_url||'').includes('bilibili.com')||String(j.id||'').includes('bilibili'));const other=jobs.filter(j=>!bili.includes(j));document.getElementById('stamp').textContent='Cập nhật: '+d.generated_at+' | Tổng '+jobs.length+' job trong '+(d.visible_days||4)+' ngày gần nhất';document.getElementById('root').textContent=d.output_root;document.getElementById('proc').textContent='process: '+(d.active_processes||[]).length;document.getElementById('channel-count').textContent=channels.length+' kênh';document.getElementById('channels').innerHTML=renderChannels(channels);document.getElementById('bili-count').textContent=bili.length+' job';document.getElementById('douyin-count').textContent=other.length+' job';document.getElementById('stats').innerHTML=`<div class="stat"><span class="muted">Bilibili</span><br><b>${bili.length}</b></div><div class="stat"><span class="muted">Douyin/khác</span><br><b>${other.length}</b></div><div class="stat"><span class="muted">Đang lỗi</span><br><b>${jobs.filter(j=>j.state==='error').length}</b></div><div class="stat"><span class="muted">Đang chạy/chờ</span><br><b>${jobs.filter(j=>['running','queued','warning'].includes(j.state)).length}</b></div>`;document.getElementById('bili-jobs').innerHTML=bili.map(renderJob).join('');document.getElementById('douyin-jobs').innerHTML=other.map(renderJob).join('');document.getElementById('bili-empty').style.display=bili.length?'none':'block'}catch(e){document.getElementById('stamp').textContent='Lỗi tải dashboard: '+e}}
setView(location.hash.slice(1)||'series');loadVoices();load();loadSeries();setInterval(load,3000);setInterval(loadSeries,15000);
</script></body></html>'''
INDEX_HTML = INDEX_HTML.replace('<!-- VOICE_OPTIONS -->', voice_options_html())
INDEX_HTML = INDEX_HTML.replace('<!-- CAPCUT_VOICE_OPTIONS -->', capcut_voice_options_html())


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        return
    def read_request_json(self):
        try:
            length = int(self.headers.get('Content-Length') or '0')
            if length <= 0:
                return {}
            raw = self.rfile.read(min(length, 1024 * 1024))
            return json.loads(raw.decode('utf-8'))
        except Exception:
            return {}

    def send_json(self, status, payload):
        self.send_body(status, json.dumps(payload, ensure_ascii=False, indent=2), 'application/json; charset=utf-8')

    def send_body(self, status, body, content_type):
        data = body.encode('utf-8') if isinstance(body, str) else body
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        origin = self.headers.get('Origin')
        self.send_header('Access-Control-Allow-Origin', origin or '*')
        self.send_header('Vary', 'Origin')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)
    def do_OPTIONS(self):
        self.send_body(204, b'', 'text/plain; charset=utf-8')

    def do_GET(self):
        if self.path == '/' or self.path.startswith('/index'):
            self.send_body(200, INDEX_HTML, 'text/html; charset=utf-8')
        elif self.path.startswith('/api/status'):
            self.send_json(200, collect_status())
        elif self.path.startswith('/api/voices'):
            self.send_json(200, voices_payload())
        elif self.path.startswith('/api/series/list'):
            self.send_json(200, series_list_payload())
        elif self.path.startswith('/api/compilation/preview'):
            query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            preview = _compilation_preview_file(
                query.get('compilation_id', [None])[0],
                query.get('index', [None])[0],
                query.get('episode', [None])[0],
            )
            if not preview:
                self.send_json(404, {'ok': False, 'error': 'preview_not_found'})
            else:
                self.send_body(200, preview.read_bytes(), COMPILATION_PREVIEW_TYPES[preview.suffix.lower()])
        elif self.path.startswith('/voice-test-cache/'):
            name = urllib.parse.urlparse(self.path).path.rsplit('/', 1)[-1]
            cache_file = voice_test_cache_file(name)
            if not cache_file or not cache_file.exists():
                self.send_json(404, {'ok': False, 'error': 'not_found'})
            else:
                self.send_body(200, cache_file.read_bytes(), 'audio/wav')
        elif self.path.startswith('/tts-cache/'):
            name = urllib.parse.urlparse(self.path).path.rsplit('/', 1)[-1]
            cache_file = chat_tts_cache_file(name)
            if not cache_file or not cache_file.exists():
                self.send_json(404, {'ok': False, 'error': 'not_found'})
            else:
                self.send_body(200, cache_file.read_bytes(), 'audio/wav')
        elif self.path.startswith('/healthz'):
            accept = self.headers.get('Accept', '')
            user_agent = self.headers.get('User-Agent', '')
            if 'text/html' in accept and 'curl' not in user_agent.lower():
                self.send_body(200, INDEX_HTML, 'text/html; charset=utf-8')
            else:
                self.send_body(200, json.dumps({'ok': True}), 'application/json; charset=utf-8')
        else:
            self.send_json(404, {'ok': False, 'error': 'not_found'})

    def do_POST(self):
        payload = self.read_request_json()
        if self.path.startswith('/api/tts'):
            self.send_json(200, synthesize_chat_tts_payload(payload))
        elif self.path.startswith('/api/voices/test'):
            self.send_json(200, voice_test_payload(payload))
        elif self.path.startswith('/api/voices/default'):
            self.send_json(200, voice_default_payload(payload))
        elif self.path.startswith('/api/voices/disable'):
            self.send_json(200, voice_disable_payload(payload))
        elif self.path.startswith('/api/voices/restore'):
            self.send_json(200, voice_restore_payload(payload))
        elif self.path.startswith('/api/voices'):
            self.send_json(200, voice_add_payload(payload))
        elif self.path.startswith('/api/series/add'):
            self.send_json(200, series_add_payload(payload))
        elif self.path.startswith('/api/series/refresh'):
            self.send_json(200, series_refresh_payload(payload))
        elif self.path.startswith('/api/series/download'):
            self.send_json(200, series_download_payload(payload))
        elif self.path.startswith('/api/series/job-status'):
            self.send_json(200, series_job_status_payload(payload))
        elif self.path.startswith('/api/compilation/plan'):
            self.send_json(200, compilation_plan_payload(payload))
        elif self.path.startswith('/api/compilation/run'):
            self.send_json(200, compilation_run_payload(payload))
        elif self.path.startswith('/api/compilation/status'):
            self.send_json(200, compilation_status_payload(payload))
        elif self.path.startswith('/api/compilation/resume'):
            self.send_json(200, compilation_resume_payload(payload))
        elif self.path.startswith('/api/compilation/cancel'):
            self.send_json(200, compilation_cancel_payload(payload))
        elif self.path.startswith('/api/job/retry'):
            self.send_json(200, retry_job_payload(payload))
        elif self.path.startswith('/api/job/cancel'):
            self.send_json(200, cancel_job_payload(payload))
        else:
            self.send_json(404, {'ok': False, 'error': 'not_found'})

def main():
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f'OpenClaw dashboard listening on http://{HOST}:{PORT}', flush=True)
    server.serve_forever()

if __name__ == '__main__':
    main()
