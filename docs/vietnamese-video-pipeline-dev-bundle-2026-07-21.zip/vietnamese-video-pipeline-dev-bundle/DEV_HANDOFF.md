# Vietnamese Video Pipeline — Developer Handoff

## Goal

Develop and test the Vietnamese dubbing/video-subtitle pipeline modules for Douyin and Bilibili workflows.

## Included content

- Top-level project readmes relevant to development.
- Current Douyin and Bilibili dubbing source code and tests, including current untracked modules and tests.
- The Vietnamese pipeline status report PDF.
- Credential-free dashboard source, packaged at `dashboard/dashboard.py`.

## Setup (high level)

Use a Python environment with the dependencies documented by the included source and project readmes. The pipeline additionally relies on its documented video, OCR, translation, and TTS runtime tooling; configure required service values through environment variables rather than source files.

## Repository state

- Current HEAD: `767d4f99bfaa9ff4436c8f98d396edd92b057a66`
- The source worktree has uncommitted/dirty changes, intentionally included where they are inside the approved source roots.

## Safety

Secrets, local profiles/sessions, runtime output, caches, media artifacts, logs, archives, and repository metadata are intentionally excluded.

For the current operational report, see `docs/bao-cao-hien-trang-pipeline-luong-tieng-viet-2026-07-21.pdf`.
